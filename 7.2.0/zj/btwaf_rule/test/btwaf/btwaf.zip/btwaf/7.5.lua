--[[
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: 黄文良 <287962566@qq.com>
# Author: 梁凯强 <1249648969@qq.com>
#-------------------------------------------------------------------

#----------------------
# WAF防火墙 for nginx
#----------------------
]]--
local cpath = "/www/server/btwaf/"
local cpath2 = "/dev/shm/"
local jpath = cpath .. "rule/"
local json = require "cjson"
local s = require "socket"
local cmspath = cpath .. "cms/"
local ngx_match = ngx.re.find
error_rule = nil

function read_file(name)
    fbody = read_file_body(jpath .. name .. '.json')
    if fbody == nil then
        return {}
    end
    return json.decode(fbody)
end

function cms_read_file(name,get)
    fbody = read_file_body(cmspath .. name .. '_' .. get .. '.json')
    if fbody == nil then
        return {}
    end
    return json.decode(fbody)
end


function get_nginx_cpu()
	return tonumber(read_file_body("/dev/shm/nginx.txt"))
end

function read_file_body(filename)
	fp = io.open(filename,'r')
	if fp == nil then
        return nil
    end
	fbody = fp:read("*a")
    fp:close()
    if fbody == '' then
        return nil
    end
	return fbody
end

function write_file(filename,body)
	fp = io.open(filename,'w')
	if fp == nil then
        return nil
    end
	fp:write(body)
	fp:flush()
	fp:close()
	return true
end

local config = json.decode(read_file_body(cpath .. 'config.json'))
local site_config = json.decode(read_file_body(cpath .. 'site.json'))

function is_ipaddr(client_ip)
	local cipn = split(client_ip,'.')
	if arrlen(cipn) < 4 then return false end
	for _,v in ipairs({1,2,3,4})
	do
		local ipv = tonumber(cipn[v])
		if ipv == nil then return false end
		if ipv > 255 or ipv < 0 then return false end
	end
	return true
end

function compare_ip_block(ips)
	if not ips then return false end
	ips = arrip(ips)
	if not is_max(ips,arrip("127.0.0.255")) then return false end
	if not is_min(ips,arrip("127.0.0.1")) then return false end
	return true
end



function get_client_ip()
	local client_ip = "unknown"
	if site_config[server_name] then
		if site_config[server_name]['cdn'] then
			for _,v in ipairs(site_config[server_name]['cdn_header'])
			do
				if request_header[v] ~= nil and request_header[v] ~= "" then
					local header_tmp = request_header[v]
					if type(header_tmp) == "table" then header_tmp = header_tmp[1] end
					client_ip = split(header_tmp,',')[1]
					if not client_ip then 
					break;
					end
					if compare_ip_block(client_ip) then
						if tostring(ngx.var.remote_addr) == tostring(client_ip) then
							client_ip = ngx.var.remote_addr
						else
							client_ip = ngx.var.remote_addr
						end
						break;
					
					end
					
					break;
				end
			end	
		end
	end
	if string.match(client_ip,"%d+%.%d+%.%d+%.%d+") == nil or not is_ipaddr(client_ip) then
		client_ip = ngx.var.remote_addr
		if client_ip == nil then
			client_ip = "unknown"
		end
	end
	return client_ip
end

function split( str,reps )
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+',function(w)
        table.insert(resultStrList,w)
    end)
    return resultStrList
end

function arrip(ipstr)
	if ipstr == 'unknown' then return {0,0,0,0} end
	if string.find(ipstr,':') then return ipstr end
	iparr = split(ipstr,'.')
	iparr[1] = tonumber(iparr[1])
	iparr[2] = tonumber(iparr[2])
	iparr[3] = tonumber(iparr[3])
	iparr[4] = tonumber(iparr[4])
	return iparr
end

function join(arr,e)
	result = ''
	length = arrlen(arr)
	for k,v in ipairs(arr)
	do
		if length == k then e = '' end
		result = result .. v .. e
	end
	return result
end

function arrlen(arr)
	if not arr then return 0 end
	count = 0
	for _,v in ipairs(arr)
	do
		count = count + 1
	end
	return count
end

function select_rule(rules)
	if not rules then return {} end
	new_rules = {}
	for i,v in ipairs(rules)
	do 
		if v[1] == 1 then
			table.insert(new_rules,v[2])
		end
	end
	return new_rules
end

function is_site_config(cname)
	if site_config[server_name] ~= nil then
		if cname == 'cc' then
			return site_config[server_name][cname]['open']
		else
			return site_config[server_name][cname]
		end
	end
	return true
end

function get_boundary()
    local header = request_header["content-type"]
    if not header then return nil end
    if type(header) == "table" then
        header = header[1]
    end

    local m = string.match(header, ";%s*boundary=\"([^\"]+)\"")
    if m then
        return m
    end
    return string.match(header, ";%s*boundary=([^\",;]+)")
end

local get_html = read_file_body(config["reqfile_path"] .. '/' .. config["get"]["reqfile"])
local post_html = read_file_body(config["reqfile_path"] .. '/' .. config["post"]["reqfile"])
local cookie_html = read_file_body(config["reqfile_path"] .. '/' .. config["cookie"]["reqfile"])
local user_agent_html = read_file_body(config["reqfile_path"] .. '/' .. config["user-agent"]["reqfile"])
local other_html = read_file_body(config["reqfile_path"] .. '/' .. config["other"]["reqfile"])
local cnlist = json.decode(read_file_body(cpath .. '/rule/cn.json'))
local scan_black_rules = read_file('scan_black')
local ip_black_rules = read_file('ip_black')
local ip_white_rules = read_file('ip_white')
local url_white_rules = read_file('url_white')
local cc_uri_white_rules = read_file('cc_uri_white')
local url_black_rules = read_file('url_black')
local user_agent_rules = select_rule(read_file('user_agent'))
local post_rules = select_rule(read_file('post'))
local cookie_rules = select_rule(read_file('cookie'))
local args_rules = select_rule(read_file('args'))
local url_rules = select_rule(read_file('url'))
local head_white_rules = read_file('head_white')
local referer_local = select_rule(read_file('referer'))


function is_min(ip1,ip2)
	if not ip1 then return false end
	if not ip2 then return false end
	n = 0
	for _,v in ipairs({1,2,3,4})
	do
		if  not ip1[v] then return false end 
		if  not ip2[v] then return false end 
		if ip1[v] == ip2[v] then
			n = n + 1
		elseif ip1[v] > ip2[v] then
			break
		else
			return false
		end
	end
	return true
end

function is_max(ip1,ip2)
	if not ip1 then return false end
	if not ip2 then return false end
	n = 0
	for _,v in ipairs({1,2,3,4})
	do
		if  not ip1[v] then return false end 
		if  not ip2[v] then return false end 
		if ip1[v] == ip2[v] then
			n = n + 1
		elseif ip1[v] < ip2[v] then
			break
		else
			return false
		end
	end
	return true
end

function compare_ip(ips)
	if ip == 'unknown' then return true end
	if string.find(ip,':') then return false end
	if not is_max(ipn,ips[2]) then return false end
	if not is_min(ipn,ips[1]) then return false end
	return true
end


function write_log(name,rule)
	local count,_ = ngx.shared.drop_ip:get(ip)
	if count then
		ngx.shared.drop_ip:incr(ip,1)
	else
		ngx.shared.drop_ip:set(ip,1,retry_cycle)
	end
	if config['log'] ~= true or is_site_config('log') ~= true then return false end
	local method = ngx.req.get_method()
	if error_rule then 
		rule = error_rule
		error_rule = nil
	end
	
	local logtmp = {ngx.localtime(),ip,method,request_uri,ngx.var.http_user_agent,name,rule}
	local logstr = json.encode(logtmp) .. "\n"
	local count,_ = ngx.shared.drop_ip:get(ip)	
	if count > retry and name ~= 'cc' then
		local safe_count,_ = ngx.shared.drop_sum:get(ip)
		if not safe_count then
			ngx.shared.drop_sum:set(ip,1,86400)
			safe_count = 1
		else
			ngx.shared.drop_sum:incr(ip,1)
		end
		local lock_time = retry_time * safe_count
		if lock_time > 86400 then lock_time = 86400 end
		logtmp = {ngx.localtime(),ip,method,request_uri,ngx.var.http_user_agent,name,retry_cycle .. '秒以内累计超过'..retry..'次以上非法请求,封锁'.. lock_time ..'秒'}
		logstr = logstr .. json.encode(logtmp) .. "\n"
		ngx.shared.drop_ip:set(ip,retry+1,lock_time)
		write_drop_ip('inc',lock_time)
	end
	write_to_file(logstr)
	inc_log(name,rule)
end

function write_drop_ip(is_drop,drop_time)
	local filename = cpath .. 'drop_ip.log'
	local fp = io.open(filename,'ab')
	if fp == nil then return false end
	local logtmp = {os.time(),ip,server_name,request_uri,drop_time,is_drop}
	local logstr = json.encode(logtmp) .. "\n"
	fp:write(logstr)
	fp:flush()
	fp:close()
	return true
end

function inc_log(name,rule)
	local total_path = cpath .. 'total.json'
	local tbody = ngx.shared.btwaf:get(total_path)
	if not tbody then
		tbody = read_file_body(total_path)
		if not tbody then return false end
	end
	local total = json.decode(tbody)
	if not total['sites'] then total['sites'] = {} end
	if not total['sites'][server_name] then total['sites'][server_name] = {} end
	if not total['sites'][server_name][name] then total['sites'][server_name][name] = 0 end
	if not total['rules'] then total['rules'] = {} end
	if not total['rules'][name] then total['rules'][name] = 0 end
	if not total['total'] then total['total'] = 0 end
	total['total'] = total['total'] + 1
	total['sites'][server_name][name] = total['sites'][server_name][name] + 1
	total['rules'][name] = total['rules'][name] + 1
	local total_log = json.encode(total)
	if not total_log then return false end
	ngx.shared.btwaf:set(total_path,total_log)
	if not ngx.shared.btwaf:get('b_btwaf_timeout') then
		write_file(total_path,total_log)
		ngx.shared.btwaf:set('b_btwaf_timeout',1,5)
	end
end

function write_to_file(logstr)
	local filename = config["logs_path"] .. '/' .. server_name .. '_' .. ngx.today() .. '.log'
	local fp = io.open(filename,'ab')
	if fp == nil then return false end
	fp:write(logstr)
	fp:flush()
	fp:close()
	return true
end

function drop_abroad()
	if ip == 'unknown' then return false end
	if not config['drop_abroad']['open'] or not is_site_config('drop_abroad') then return false end	
	for _,v in ipairs(cnlist)
	do
		if compare_ip(v) then return false end
	end
	ngx.exit(config['drop_abroad']['status'])
	return true
end

function drop()
	local count,_ = ngx.shared.drop_ip:get(ip)
	if not count then return false end
	if count > retry then
		ngx.exit(config['cc']['status'])
		return true
	end
	return false
end

function cc()
	if not config['cc']['open'] or not site_cc then return false end
	local token = ngx.md5(ip .. '_' .. request_uri)
	local count,_ = ngx.shared.btwaf:get(token)
	if count then
		if count > limit*2 then
			local safe_count,_ = ngx.shared.drop_sum:get(ip)
			if not safe_count then
				ngx.shared.drop_sum:set(ip,1,86400)
				safe_count = 1
			else
				ngx.shared.drop_sum:incr(ip,1)
			end
			local lock_time = (endtime * safe_count)
			if lock_time > 86400 then lock_time = 86400 end
			ngx.shared.drop_ip:set(ip,retry+1,lock_time)
			write_log('cc',cycle..'秒内累计超过'..limit..'次请求,封锁' .. lock_time .. '秒')
			write_drop_ip('cc',lock_time)
			if not server_name then
				insert_ip_list(ip,lock_time,os.time(),'1111')
			else
				insert_ip_list(ip,lock_time,os.time(),server_name)
			end
			
			ngx.exit(config['cc']['status'])
			return true
		else
			ngx.shared.btwaf:incr(token,1)
		end
	else
		ngx.shared.btwaf:set(token,1,cycle)
	end
	return false
end

--强制验证是否使用正常浏览器访问网站
function cc_increase()
	
	if not config['cc']['open'] or not site_cc then return false end
	if not site_config[server_name] then return false end
	if not site_config[server_name]['cc']['increase'] then return false end
	local cache_token = ngx.md5(ip .. '_' .. server_name)
	--判断是否已经通过验证
	if ngx.shared.btwaf:get(cache_token) then  return false end
	if cc_uri_white() then
		ngx.shared.btwaf:delete(cache_token .. '_key')
		ngx.shared.btwaf:set(cache_token,1,60)
		return false 
	end
	if security_verification() then return false end
	send_check_heml(cache_token)
end

--发送验证
function send_check_heml(cache_token)
	local check_key = tostring(math.random(10000000,99999999))
	ngx.shared.btwaf:set(cache_token .. '_key',check_key,60)
	local vargs = '&btwaf='
	local sargs = string.gsub(request_uri,'.?btwaf=.*','')
	if not string.find(sargs,'?',1,true) then vargs = '?btwaf=' end
	local safe_count = ngx.shared.drop_ip:get(ip)
	if not safe_count then
		ngx.shared.drop_ip:set(ip,1,endtime)
		safe_count = 1
	else
		ngx.shared.drop_ip:incr(ip,1)
		safe_count = safe_count +1
	end

	if safe_count >= retry then
		local safe_count2,_ = ngx.shared.drop_sum:get(ip)
		if not safe_count2 then safe_count2=1 end
		retry_time = site_config[server_name]['retry_time']
		local lock_time = (retry_time * safe_count2)
		if lock_time > 86400 then lock_time = 86400 end
		if not server_name then
			insert_ip_list(ip,lock_time,os.time(),'1111')
		else
			insert_ip_list(ip,lock_time,os.time(),server_name)
		end
		write_log('cc','累计超过'.. retry ..'次验证失败,封锁' .. lock_time .. '秒')
		write_drop_ip('cc',lock_time)
	end

	local check_html = [[<html><meta charset="utf-8" /><title>检测中</title><div>跳转中</div></html>
<script> window.location.href ="]] .. sargs .. vargs .. check_key .. [["; </script>]]
	ngx.header.content_type = "text/html;charset=utf8"
	ngx.say(check_html)
	ngx.exit(403)
end

function security_verification()
	if  not uri_request_args['btwaf'] then return false end
	local cache_token = ngx.md5(ip .. '_' .. server_name)
	check_key = ngx.shared.btwaf:get(cache_token .. '_key')
	if check_key == uri_request_args['btwaf'] then
		ngx.shared.btwaf:delete(cache_token .. '_key')
		ngx.shared.btwaf:set(cache_token,1,6400)
		return true
	end
	return false
end

function scan_black()
	if not config['scan']['open'] or not is_site_config('scan') then return false end
	if is_ngx_match(scan_black_rules['cookie'],request_header['cookie'],false) then
		write_log('scan','regular')
		ngx.exit(config['scan']['status'])
		return true
	end
	if is_ngx_match(scan_black_rules['args'],request_uri,false) then
		write_log('scan','regular')
		ngx.exit(config['scan']['status'])
		return true
	end
	for key,value in pairs(request_header)
	do
		if is_ngx_match(scan_black_rules['header'],key,false) then
			write_log('scan','regular')
			ngx.exit(config['scan']['status'])
			return true
		end
	end
	return false
end

function ip_black()
	for _,rule in ipairs(ip_black_rules)
	do
		if compare_ip(rule) then 
			ngx.exit(config['cc']['status'])
			return true 
		end
	end
	return false
end

function ip_white()
	for _,rule in ipairs(ip_white_rules)
	do
		if compare_ip(rule) then 
			return true 
		end
	end
	return false
end

function url_white()
	if is_ngx_match(url_white_rules,request_uri,false) then
		return true
	end
	if site_config[server_name] ~= nil then
		if is_ngx_match(site_config[server_name]['url_white'],request_uri,false) then
			return true
		end
	end
	return false
end

function url_black()
	if is_ngx_match(url_black_rules,request_uri,false) then
		ngx.exit(config['get']['status'])
		return true
	end
	return false
end

function head()
	if method ~= 'HEAD' then return false end
	for _,v in ipairs(head_white_rules)
	do
		if ngx_match(uri,v,"isjo") then
			return false
		end
	end
	spiders = {'spider','bot'}
	for _,v in ipairs(spiders)
	do
		if ngx_match(request_header['user-agent'],v,"isjo") then
			return false
		end
	end
	write_log('head','禁止HEAD请求')
	ngx.shared.btwaf:set(ip,retry,endtime)
	write_drop_ip('head',endtime)
	ngx.exit(444)
end

function user_agent()
	if not config['user-agent']['open'] or not is_site_config('user-agent') then return false end	
	if is_ngx_match(user_agent_rules,request_header['user-agent'],'user_agent') then
		write_log('user_agent','regular')
		return_html(config['user-agent']['status'],user_agent_html)
		return true
	end
	return false
end

function de_dict (l_key,l_data)
	if type(l_data) ~= "table" then return l_data end
	if arrlen(l_data) == 0 then return l_data end
	if not l_data then return false end
	local r_data = {}
	if arrlen(l_data) == 100 then 
		write_log('post','非法请求!!!!')
		return_html(config['post']['status'],post_html)
		return true
	end
	for li,lv in pairs(l_data)
	do
		r_data[l_key..tostring(li)] = lv
	end

	return r_data
end

function post()
	if not config['post']['open'] or not is_site_config('post') then return false end	
	if method ~= "POST" then return false end
	if post_referer() then return true end
	content_length=tonumber(request_header['content-length'])
	max_len = 640 * 1020000
	if content_length > max_len then return false end
	if get_boundary() then return false end
	ngx.req.read_body()
	request_args = ngx.req.get_post_args()
	if not request_args then
		return false
	end
	local list_data = nil
	if type(request_args)=='table' then
		for k,v in pairs(request_args)
		do
			if type(v)=='table' then
				list_data=de_dict(k,v)
			end
            if type(v)=='string' then
				if not  string.find(v,'^data:.+/.+;base64,') then
					if (#v) >=200000 then
						write_log('post',k..'     参数值长度超过20w已被系统拦截')
						return_html(config['post']['status'],post_html)
						return true
					end
				end
			end
		end
	end
	if is_ngx_match(post_rules,request_args,'post') then
		write_log('post','regular')
		return_html(config['post']['status'],post_html)
		return true
	end
	if list_data then
		if is_ngx_match(post_rules,list_data,'post') then
			write_log('post','regular')
			return_html(config['post']['status'],post_html)
			return true
		end	
	end

	return false
end


function chekc_data_table(data)
	if type(data) ~= 'table' then return false end
	for k,v in ipairs(data)
	do
		return return_message(200,type(v))

	end
	return false
	-- body
end



function disable_upload_ext(ext)
	if not ext then return false end
	ext = string.lower(ext)
	if is_ngx_match(site_config[server_name]['disable_upload_ext'],ext,'post') then
		write_log('upload_ext','上传扩展名黑名单')
		return_html(config['other']['status'],other_html)
		return true
	end
end

function post_data()
	if not config['post']['open'] or not is_site_config('post') then return false end
	if method ~= "POST" then return false end
	content_length=tonumber(request_header['content-length'])
	if not content_length then return false end
	max_len = 2560 * 1024000
	if content_length > max_len then return false end
	local boundary = get_boundary()
	if boundary then
		ngx.req.read_body()
		local data = ngx.req.get_body_data()
		if not data then return false end
		local tmp_upload = ngx.re.match(data,[[filename=+\"(.+)\.(.*)\"]])
		if  tmp_upload and tmp_upload[2] then 
			disable_upload_ext(tmp_upload[2])
		end
		local tmp2=ngx.re.match(ngx.req.get_body_data(),[[Content-Type:[^\+]{200}]]) 
		if tmp2 and tmp2[0] then 
			disable_upload_ext(tmp2[0])
		end
		data=string.gsub(data,'\r','')
		data=string.gsub(data,'\n','')
		data=string.gsub(data,'\t','')
		local tmp_pyload = ngx.re.match(data,[[filename=.+Content-Type]])
		--return return_message(200,tmp_pyload[0])
		if tmp_pyload and tmp_pyload[0] then
			disable_upload_ext(tmp_pyload[0])
		end
		return false
	end
	return false
end


function return_post_data()
	if method ~= "POST" then return false end
	content_length=tonumber(request_header['content-length'])
	if not content_length then return false end
	max_len = 2560 * 1024000
	if content_length > max_len then return false end
	local boundary = get_boundary()
	if boundary then
		ngx.req.read_body()
		local data = ngx.req.get_body_data()
		if not data then return false end
		local tmp = ngx.re.match(data,[[filename=+\"(.+)\.(.*)\"]])
		if not tmp then return false end
		if not tmp[2] then return false end
		return tmp[2]
		
	end
	return false
end




function data_in_php(data)
	if not data then
		return false
	else
		if is_ngx_match('php',data,'post') then
			write_log('upload_ext','上传扩展名黑名单')
			return_html(config['other']['status'],other_html)
			return true
		else
			return false
		end
	end
end



function cookie()
	if not config['cookie']['open'] or not is_site_config('cookie') then return false end
	if not request_header['cookie'] then return false end
    if type(request_header['cookie']) ~= "string" then return false end
	request_cookie = string.lower(request_header['cookie'])
	if is_ngx_match(cookie_rules,request_cookie,'cookie') then
		write_log('cookie','regular')
		return_html(config['cookie']['status'],cookie_html)
		return true
	end
	return false
end


function de_dict2(l_key,l_data)
	if type(l_data) ~= "table" then return l_data end
	if arrlen(l_data) == 0 then return l_data end
	if not l_data then return false end
	local r_data = {}
	if arrlen(l_data) == 100 then 
		write_log('post','非法请求!!!!')
		return_html(config['post']['status'],post_html)
		return true
	end
	for li,lv in pairs(l_data)
	do
		r_data[l_key..tostring(li)] = lv
	end

	return r_data
end

function args()
	if not config['get']['open'] or not is_site_config('get') then return false end	
	local list_data = nil
	if type(uri_request_args)=='table' then
		for k,v in pairs(uri_request_args)
		do
			if type(v)=='table' then
				list_data=de_dict2(k,v)
			end
		end
	end	
	if list_data then
		if is_ngx_match(args_rules,list_data,'post') then
			write_log('args','regular')
			return_html(config['get']['status'],get_html)
			return true
		end	
	end
	if is_ngx_match(args_rules,uri_request_args,'args') then
		write_log('args','regular')
		return_html(config['get']['status'],get_html)
		return true
	end
	return false
end

function url()
	if not config['get']['open'] or not is_site_config('get') then return false end
	--正则--
	if is_ngx_match(url_rules,uri,'url') then
		write_log('url','regular')
		return_html(config['get']['status'],get_html)
		return true
	end
	return false
end

function php_path()
	if site_config[server_name] == nil then return false end
	for _,rule in ipairs(site_config[server_name]['disable_php_path'])
	do
		--if string.find(uri,rule .. "/.*\\.php$") then
		if ngx_match(uri,rule .. "/?.*\\.php$","isjo") then
			write_log('php_path','regular')
			return_html(config['other']['status'],other_html)
			return return_message(200,uri)
		end
	end
	return false
end

function url_path()
	if site_config[server_name] == nil then return false end
	for _,rule in ipairs(site_config[server_name]['disable_path'])
	do
		if ngx_match(uri,rule,"isjo") then
			write_log('path','regular')
			return_html(config['other']['status'],other_html)
			return true
		end
	end
	return false
end

function url_ext()
	if site_config[server_name] == nil then return false end
	for _,rule in ipairs(site_config[server_name]['disable_ext'])
	do
		if ngx_match(uri,"\\."..rule.."$","isjo") then
			write_log('url_ext','regular')
			return_html(config['other']['status'],other_html)
			return true
		end
	end
	return false
end

function url_rule_ex()
	if site_config[server_name] == nil then return false end
	if method == "POST" and not request_args then
		content_length=tonumber(request_header['content-length'])
		max_len = 640 * 102400000
		request_args = nil
		if content_length < max_len then
			ngx.req.read_body()
			request_args = ngx.req.get_post_args()
		end
	end
	for _,rule in ipairs(site_config[server_name]['url_rule'])
	do
		if ngx_match(uri,rule[1],"isjo") then
			if is_ngx_match(rule[2],uri_request_args,false) then
				write_log('url_rule','regular')
				return_html(config['other']['status'],other_html)
				return true
			end
			
			if method == "POST" and request_args ~= nil then 
				if is_ngx_match(rule[2],request_args,'post') then
					write_log('post','regular')
					return_html(config['other']['status'],other_html)
					return true
				end
			end
		end
	end
	return false
end

function url_tell()
	if site_config[server_name] == nil then return false end
	for _,rule in ipairs(site_config[server_name]['url_tell'])
	do
		if ngx_match(uri,rule[1],"isjo") then
			if uri_request_args[rule[2]] ~= rule[3] then
				write_log('url_tell','regular')
				return_html(config['other']['status'],other_html)
				return true
			end
		end
	end
	return false
end

function continue_key(key)
	key = tostring(key)
	if string.len(key) > 64 then return false end;
	local keys = {"content","contents","body","msg","file","files","img","newcontent","message","subject","kw","srchtxt",""}
	for _,k in ipairs(keys)
	do
		if k == key then return false end;
	end
	return true;
end

function cms_continue_key(key)
	key = tostring(key)
	if string.len(key) > 64 then return false end;
	local keys = {"content","contents","body","msg","file","files","img","newcontent","message","subject","kw","srchtxt",""}
	for _,k in ipairs(keys)
	do
		if k == key then return false end;
	end
	return true;
end


function is_ngx_match(rules,sbody,rule_name)
	if rules == nil or sbody == nil then return false end
	if type(sbody) == "string" then
		sbody = {sbody}
	end
	
	if type(rules) == "string" then
		rules = {rules}
	end

	for k,body in pairs(sbody)
    do  
		if continue_key(k) then
			for i,rule in ipairs(rules)
			do
				if site_config[server_name] and rule_name then
					local n = i - 1
					for _,j in ipairs(site_config[server_name]['disable_rule'][rule_name])
					do
						if n == j then
							rule = ""
						end
					end
				end
				
				if body and rule ~="" then
					if type(body) == "string" then
						if ngx_match(ngx.unescape_uri(body),rule,"isjo") then
							error_rule = rule .. ' >> ' .. k .. ':' .. body
							return true
						end
					end
					if type(k) == "string" then
						if ngx_match(ngx.unescape_uri(k),rule,"isjo") then
							error_rule = rule .. ' >> ' .. k
							return true
						end
					end
				end
			end
		end
	end
	return false
end


function is_is_ngx_match(rules,sbody,rule_name)
	if rules == nil or sbody == nil then return false end
	if type(sbody) == "string" then
		sbody = {sbody}
	end
	
	if type(rules) == "string" then
		rules = {rules}
    end
    
	for k,body in pairs(sbody)
    do  
		if cms_continue_key(k) then
			for i,rule in ipairs(rules)
			do
				if site_config[server_name] and rule_name then
					local n = i - 1
					for _,j in ipairs(site_config[server_name]['disable_rule'][rule_name])
					do
						if n == j then
							rule = ""
						end
					end
				end
				
				if body and rule ~="" then
					if type(body) == "string" then
						if ngx_match(ngx.unescape_uri(body),rule,"isjo") then
							error_rule = rule .. ' >> ' .. k .. ':' .. body
							return true
						end
					end
					if type(k) == "string" then
						if ngx_match(ngx.unescape_uri(k),rule,"isjo") then
							error_rule = rule .. ' >> ' .. k
							return true
						end
					end
				end
			end
		end
	end
	return false
end

function is_key(keys,values)
	if keys == nil or values == nil then return false end
	if type(values) == "string" then
		values = {values}
	end
	
	if type(keys) == "string" then
		keys = {keys}
	end
	
	for _,value in pairs(values)
	do
		if type(value) == "boolean" or value == "" then return false end
		sval = ngx.unescape_uri(string.lower(ngx.unescape_uri(value)))
		for _,v in ipairs(keys)
        do
			if v == sval then
				return true
			end
        end
	end
	return false
end

function get_return_state(rstate,rmsg)
	result = {}
	result['status'] = rstate
	result['msg'] = rmsg
	return result
end

function get_btwaf_drop_ip()
	local data =  ngx.shared.drop_ip:get_keys(0)
	return data
end

function remove_btwaf_drop_ip()
	if not uri_request_args['ip'] or not is_ipaddr(uri_request_args['ip']) then return get_return_state(true,'格式错误') end
	if ngx.shared.btwaf:get(cpath2 .. 'stop_ip') then
		ret=ngx.shared.btwaf:get(cpath2 .. 'stop_ip')
		ip_data=json.decode(ret)
        result=is_chekc_table(ip_data,uri_request_args['ip'])
        os.execute("sleep " .. 0.6)
        ret2=ngx.shared.btwaf:get(cpath2 .. 'stop_ip')
        ip_data2=json.decode(ret2)
        if result == 3 then
	    	for k,v in pairs(ip_data2)
		    do
		        if uri_request_args['ip'] == v['ip'] then 
		            v['time']=0
		        end
		    end
		end
	  	save_ip_on(ip_data2)
	end
	ngx.shared.drop_ip:delete(uri_request_args['ip'])
	return get_return_state(true,uri_request_args['ip'] .. '已解封')
end

function clean_btwaf_drop_ip()
	if ngx.shared.btwaf:get(cpath2 .. 'stop_ip') then
        ret2=ngx.shared.btwaf:get(cpath2 .. 'stop_ip')
        ip_data2=json.decode(ret2)
    	for k,v in pairs(ip_data2)
	    do
	            v['time']=0
	    end
	  	save_ip_on(ip_data2)
	  	os.execute("sleep " .. 2)
	end
	local data = get_btwaf_drop_ip()
	for _,value in ipairs(data)
	do
		ngx.shared.drop_ip:delete(value)
	end
	return get_return_state(true,'已解封所有封锁IP')
end

function min_route()
	if ngx.var.remote_addr ~= '127.0.0.1' then return false end
	if uri == '/get_btwaf_drop_ip' then
		return_message(200,get_btwaf_drop_ip())
	elseif uri == '/remove_btwaf_drop_ip' then
		return_message(200,remove_btwaf_drop_ip())
	elseif uri == '/clean_btwaf_drop_ip' then
		return_message(200,clean_btwaf_drop_ip())
	end
end

function return_message(status,msg)
	ngx.header.content_type = "application/json;"
	ngx.status = status
	ngx.say(json.encode(msg))
    ngx.exit(status)
end

function return_html(status,html)
	ngx.header.content_type = "text/html"
    ngx.status = status
    ngx.say(html)
    ngx.exit(status)
end

function get_server_name()
	local c_name = ngx.var.server_name
	local my_name = ngx.shared.btwaf:get(c_name)
	if my_name then return my_name end
	local tmp = read_file_body(cpath .. '/domains.json')
	if not tmp then return c_name end
	local domains = json.decode(tmp)
	for _,v in ipairs(domains)
	do
		for _,d_name in ipairs(v['domains'])
		do
			if c_name == d_name then
				ngx.shared.btwaf:set(c_name,v['name'],3600)
				return v['name']
			end
		end
	end
	return c_name
end

function return_cms(server_name)
	local cms_list = read_file_body(cpath .. '/domains2.json')
	if cms_list then
		local cms_json = json.decode(cms_list)
		for v,k in ipairs(cms_json)
		do 	
			for _,k2 in ipairs(k["domains"])
				do
				if server_name == k2
					then
					return k["cms"]
				end
			end

		end
	end
end


function cms_rule(name,get)
    if not config['get']['open'] or not is_site_config('get') then return false end
    local cms_rule = select_rule(cms_read_file(name,get))
    if referer() then return true end 
	if is_is_ngx_match(cms_rule,uri_request_args,'args') then
	    write_log('get','regular')
		return_html(config['get']['status'],get_html)
		return true
	end
	return false
end

function cms_rule_post(name,get)
	if not config['post']['open'] or not is_site_config('post') then return false end	
	if method ~= "POST" then return false end
	if post_referer() then return true end
	local cms_rule = select_rule(cms_read_file(name,get))
	content_length=tonumber(request_header['content-length'])
	max_len = 640 * 10240000
	if content_length > max_len then return false end
	if get_boundary() then return false end
	ngx.req.read_body()
	request_args = ngx.req.get_post_args()
	if not request_args then
		return false
	end
	if is_is_ngx_match(cms_rule,request_args,'post') then
		write_log('post','regular')
		return_html(config['post']['status'],post_html)
		return true
	end
	return false
end

function post_referer()
	if method ~= "POST" then return false end
	if is_ngx_match(referer_local,request_header['Referer'],'post') then
		write_log('post_referer','regular')
		return_html(config['post']['status'],post_html)
		return true
	end
	return false
end

function referer()
	if method ~= "GET" then return false end
	if not config['get']['open'] or not is_site_config('get') then return false end
	if is_ngx_match(referer_local,request_header['Referer'],'args') then
		write_log('get_referer','regular')
		return_html(config['get']['status'],get_html)
		return true
	end
	return false
end


function get_zhizu_list()
	fbody=read_file_body(cpath .. 'zhi.json')
	if fbody == nil then
        return nil
    end
    ngx.shared.btwaf:set('zhi_list',fbody,86400)
    return json.decode(fbody)
end

function ua_whilie(ua)
	ua_list=ngx.shared.btwaf:get('zhi_list')
	if ua_list == nil then 
		get_zhizu_list() 
	else
		ua_list2=ngx.shared.btwaf:get('zhi_list')
		if ua_list2 ~= nil then
			ua_list2 = json.decode(ua_list2)
			for _,k in ipairs(ua_list2['continue'])
				do
					if k ~= nil then
						local ua=string.find(tostring(ua),tostring(k))
						if ua ~= nil then
							return true
						end
					end
			end
		end
	end
end

function  host_pachong(ip,id,ua_key)
	if not ip then return 33 end
	if not id then return 33 end
	if not ua_key then return 33 end
	key_id=ngx.shared.btwaf:get(id..'__lock_____1111')
	if key_id == nil then 
		-- 获取是否是爬虫
		ngx.shared.btwaf:set(id..'__lock_____1111',1)
		data11111=s.dns.tohostname(tostring(ip))
		if not data11111 then 
			ngx.shared.btwaf:delete(id..'__lock_____1111')
			return 33
		end
		types=string.find(string.lower(tostring(data11111)),string.lower(tostring(ua_key)))
		-- 此刻是爬虫
		if types~=nil then 
			pachong=get_zhizu_json(id)
			pachong=json.decode(pachong)
			table.insert(pachong,ip)
			save_data_on(id,pachong)
			ngx.shared.btwaf:delete(id..'__lock_____1111')
			return 2
		else
			ngx.shared.btwaf:delete(id..'__lock_____1111')
			return 33
		end
		ngx.shared.btwaf:delete(id..'__lock_____1111')
	else
		return 1888
	end	
end

function zhizu_ua_chkec(ua)
	ua_list=ngx.shared.btwaf:get('zhi_list')
	if not ua_list  then get_zhizu_list() end
	ua_list2=ngx.shared.btwaf:get('zhi_list')
	if ua_list2 ~= nil then
		ua_list2 = json.decode(ua_list2)
		for _,k in ipairs(ua_list2['types'])
		do
				if k['ua_key'] ~= nil then
					local fa=string.find(string.lower(tostring(ua)),string.lower(tostring(k['ua_key'])))
					if fa ~= nil then
						return tonumber(k['id'])
					end
				end
		end
	end
end

function fei_zhizu_check(ip)
	ret=ngx.shared.btwaf:get('fei_pachong'..ip)
	if not ret then
		return false
	else
		return true
	end
end


function get_zhizu_json(name)
	data = read_file_body(cpath .. tostring(name) ..'.json')
	if not data then 
		data={}
	end 
	return data
end


function save_data_on(name,data)
	local extime=18000
	data=json.encode(data)
	ngx.shared.btwaf:set(cpath .. name,data,extime)
	if not ngx.shared.btwaf:get(cpath .. name .. '_lock') then
		ngx.shared.btwaf:set(cpath .. name .. '_lock',1,5) 
		write_file(cpath .. name .. '.json',data)
	end
end

function get_ua_key(id)
	zhizu_list=get_zhizu_list()
	if not zhizu_list then return false end
	for _,k in ipairs(zhizu_list['types'])
	do 	
		if tonumber(id) == tonumber(k['id']) then
			return k['host_key']
		end
	end
end

function zhizu_chekc(name,ip)
	data=get_zhizu_json(name)
	ngx.shared.btwaf:set(cpath .. name,data,1800)
	for _,k in ipairs(json.decode(data))
	do
		if tostring(k) == tostring(ip) then 
			return true
		end
	end
end

--蜘蛛爬虫入口
function reptile_entrance(ua,ip)
	if not ip then return 1 end
	ua_whilie_check=ua_whilie(ua)
	if  ua_whilie_check then return 4 end
	reptile_id=zhizu_ua_chkec(ua)
	if not reptile_id then return 4 end
	get_ua_key22=get_ua_key(tonumber(reptile_id))
	if not get_ua_key22 then return 6 end
	if get_ua_key22 == nil then return 6 end 
	--非蜘蛛池 
	if fei_zhizu_check(ip) then return 33 end

	if tonumber(reptile_id) == '3' then 
		if zhizu_chekc(reptile_id,ip) then
			return 2 
		else
			return 33
		end
	end
	-- 查看是否是蜘蛛
	if zhizu_chekc(reptile_id,ip) then
		return 2
	else
		ret=host_pachong(ip,reptile_id,get_ua_key22)
		return ret
	end
end

function X_Forwarded()
	if method ~= "GET" then return false end
	if not config['get']['open'] or not is_site_config('get') then return false end	
	if is_ngx_match(args_rules,request_header['X-forwarded-For'],'args') then
		write_log('args','regular')
		return_html(config['get']['status'],get_html)
		return true
	end
	return false
end

function post_X_Forwarded()
	if not config['post']['open'] or not is_site_config('post') then return false end	
	if method ~= "POST" then return false end
	if is_ngx_match(post_rules,request_header['X-forwarded-For'],'post') then
		write_log('post','regular')
		return_html(config['post']['status'],post_html)
		return true
	end
	return false
end



--local cms_rules = select_rule(json.decode(rules_cms_read_file('wordpress')))
function rules_cms_read_file(name)
    fbody = read_file_body('/www/server/btwaf/cms/'.. name ..'.json')
    if fbody == nil then
        return {}
    end
    return fbody
end 


function cms_is_ngx_match(cms_rules,uri,request_args,rules)
	if cms_rules == nil or uri == nil  or request_args == nil or rules == nil then return false end
    if type(rules) == "string" then
		rules = {rules}
    end
    if type(request_args) == "string" then
		request_args = {request_args}
	end
    --uri=ngx.unescape_uri(uri)
    if cms_rules[uri] ~= nil then
        
        for _,body in pairs(split(cms_rules[uri],'|'))
        do  
            if request_args[body] ~= nil then
                for _,v in pairs(rules)
                do 
                	for k,value in pairs(request_args) 
                	do 
                		if k == body then
                			--return return_message(200,v) 
                			if ngx_match(ngx.unescape_uri(request_args[body]),v,"isjo") then
	                        	return true
	                    	end
                		end
	               
	                end
                	
                end
            end
                
        end
    end   
    return false
end


-- CMS白名单
function  cms_url_white(cms)

	fbody = read_file_body('/www/server/btwaf/cms/'.. cms ..'_white.json')
    if fbody == nil then
        return {}
	end
	if is_ngx_match(json.decode(fbody) ,request_uri,false) then
		return true
	end
end

function select_rule_cms(rules)
	if not rules then return {} end
	new_rules = {}
	for i,v in ipairs(rules)
	do 	
	    print(v[1])
		new_rules[v[1]] = v[2]
		
	end
	return new_rules
end


function  post_data_chekc()
		if not config['post']['open'] or not is_site_config('post') then return false end
		if method =="POST" then
			if return_post_data() then return false end
			request_args = ngx.req.get_post_args()
			if not request_args then return false end
			if not request_header['Content-Type'] then return false end
			if type(request_header['Content-Type']) ~= "string" then return false end
			av=string.match(request_header['Content-Type'],"=.+")
			if not av then return false end
			ac=split(av,'=')
			if not ac then return false end 
			list_list=nil
			for i,v in ipairs(ac)
			do
				 list_list='--'..v
			end
			if not list_list then return false end 
			aaa=nil
			for k,v in pairs(request_args)
			do
			 	aaa=v
			end
			if not aaa then return false end 
			if tostring(aaa) == 'true' then return false end
			if type(aaa) ~= "string" then return false end
			data_len=split(aaa,list_list)
			--return return_message(200,data_len)
			if not data_len then return false end
			if arrlen(data_len) ==0 then return false end

			if is_ngx_match(post_rules,data_len,'post') then
				write_log('post','regular')
				return_html(config['post']['status'],post_html)
				return true
			end

		end
end


function is_chekc_table(data,strings)
	if type(data) ~= 'table' then return 1 end 
	if not data then return 1 end
	data=chekc_ip_timeout(data)
	for k,v in pairs(data)
    do
        if strings ==v['ip'] then
            return 3
        end
    end
    return 2
end

-- 判断该IP 是否已经过期
function chekc_ip_timeout(ip_data)
	resutl=false
	local ret_time=os.time()-180
	for k,v in pairs(ip_data)
	do
		if (v['time']+v['timeout'])<ret_time then
			table.remove(ip_data,k)
			result=true
		end
	end
	if result then
		local extime=18000
		name='stop_ip'
		data=json.encode(ip_data)
		ngx.shared.btwaf:set(cpath2 .. name,data,extime)
		locak_file=read_file_body(cpath2 .. 'stop_ip2.lock')
		if not locak_file then
				write_file(cpath2 .. 'stop_ip2.lock','1')
		end
	end
	return ip_data
end

function insert_ip_list(ip,time,timeout,server_name)
		if time<300 then return false end
        if not ngx.shared.btwaf:get(cpath2 .. 'stop_ip') then
            ip_data=json.decode(read_file_body(cpath2..'stop_ip.json'))
            if not ip_data then return false end
     		result=is_chekc_table(ip_data,ip)
     		if result ==1 then 
     			local myAlldataList={}
                local testData2={timeout=timeout,ip=ip,time=time,site=server_name}
                ip_data={}
                table.insert(ip_data,testData2)
                save_ip_on(ip_data)
                --data=json.encode(ip_data)
            	--write_file(cpath..'stop_ip.json',data)

     		elseif result==2 then 
     			local myAlldataList={}
                local testData2={timeout=timeout,ip=ip,time=time,site=server_name}
                table.insert(ip_data,testData2)
                save_ip_on(ip_data)
           	elseif result ==3 then
            	for k,v in pairs(ip_data)
			    do
			        if ip ==v['ip'] then 
			            v['time']=time
			            v['timeout']=timeout
			        end
				end
			    save_ip_on(ip_data)
     		end

        else
        	ret=ngx.shared.btwaf:get(cpath2 .. 'stop_ip')
        	ip_data=json.decode(ret)
        	result=is_chekc_table(ip_data,ip)
        	if result ==1 then 
         			local myAlldataList={}
	                local testData2={timeout=timeout,ip=ip,time=time,site=server_name}
	                ip_data={}
	                table.insert(ip_data,testData2)
	                save_ip_on(ip_data)

        	elseif  result==2 then 
         			local myAlldataList={}
	                local testData2={timeout=timeout,ip=ip,time=time,site=server_name}
	                table.insert(ip_data,testData2)
	                save_ip_on(ip_data)

	        elseif result == 3 then
	            	for k,v in pairs(ip_data)
				    do
				        if ip ==v['ip'] then 
				            v['time']=time
				        end
				    end
				  	save_ip_on(ip_data)
         	end
		end	
end

function save_ip_on(data)
	locak_file=read_file_body(cpath2 .. 'stop_ip.lock')
	if not locak_file then
			write_file(cpath2 .. 'stop_ip.lock','1')
	end
	name='stop_ip'
	local extime=18000
	data=json.encode(data)
	ngx.shared.btwaf:set(cpath2 .. name,data,extime)
	if not ngx.shared.btwaf:get(cpath2 .. name .. '_lock') then
		ngx.shared.btwaf:set(cpath2 .. name .. '_lock',1,0.5)
		write_file(cpath2 .. name .. '.json',data)
	end
end

function cc_uri_white()
	if cc_increase_static() then return true end
	if is_ngx_match(cc_uri_white_rules,uri,false) then
		return true
	end
	if site_config[server_name] ~= nil then
		if is_ngx_match(site_config[server_name]['cc_uri_white'],uri,false) then
			return true
		end
	end
	return false
end


function cc_increase_static()
	local keys = {"css","js","png","gif","ico","jpg","jpeg","bmp","flush","swf","pdf","rar","zip","doc","docx","xlsx"}
	for _,k in ipairs(keys)
	do
		local aa="/?.*\\."..k.."$"
		if ngx_match(uri,aa,"isjo") then
			return true
		end
	end
	return false
end


function set_inser_cc()
	if config['cc_automatic'] then
		cc_time=config['cc_time']*10
		cc_retry_cycle=config['cc_retry_cycle']

		if not ngx.shared.btwaf:get('cc_automatic') then
			ngx.shared.btwaf:set('cc_automatic',1,cc_time)

		else
			ret22222=ngx.shared.btwaf:get('cc_automatic')
			ngx.shared.btwaf:incr('cc_automatic',1)
			if ret22222>cc_retry_cycle*2 then
					site_config[server_name]['cc']['increase']=true
					cc_increase()
			else
				local site_config2 = json.decode(read_file_body(cpath .. 'site.json'))
				if site_config2[server_name] == nil then
					return false
				end
				if not site_config2[server_name]['cc']['increase'] then
					site_config[server_name]['cc']['increase']=false
				end
			end
		end
	end
end



function get_body_character_string()
   local char_string=config['uri_find']
   if not char_string then return false end
   if arrlen(char_string) ==0 then return false end
   if arrlen(char_string) >=1 then return char_string end
   -- body
end

function url_find(uri)
	local get_body=get_body_character_string()
	if get_body then
		for __,v in pairs(get_body)
		do
			if string.find(uri,v) then 
				ngx.exit(444)
			end
		end
	end
end


function get_config_ua_white()
   local char_string=config['ua_white']
   if not char_string then return false end
   if arrlen(char_string) ==0 then return false end
   if arrlen(char_string) >=1 then return char_string end
   -- body
end


function get_config_ua_black()
   local char_string=config['ua_black']
   if not char_string then return false end
   if arrlen(char_string) ==0 then return false end
   if arrlen(char_string) >=1 then return char_string end
   -- body
end


-- CC UA 白名单
function ua_white()
	local ua=ngx.req.get_headers()['user-agent']
	if not ua then return false end
	local get_ua_list=get_config_ua_white()
	if arrlen(get_ua_list)==0 then return false end
	if get_ua_list then
		for __,v in pairs(get_ua_list)
		do
			if string.find(ua,v) then 
				return true
			end
		end
	end
	return false
end

-- CC UA 黑名单
function ua_black()
	local ua=ngx.req.get_headers()['user-agent']
	if not ua then return false end
	local get_ua_list=get_config_ua_black()
	if arrlen(get_ua_list)==0 then return false end
	if get_ua_list then
		for __,v in pairs(get_ua_list)
		do
			if string.find(ua,v) then 
				ngx.exit(444)
			end
		end
	end
	return false
end



function run_btwaf()
	server_name = string.gsub(get_server_name(),'_','.')
	if not config['open'] or not is_site_config('open') then return false end
	if ua_white() then return true end
	ua_black()
	error_rule = nil
	request_uri = ngx.var.request_uri
	uri = ngx.unescape_uri(ngx.var.uri)
	url_find(request_uri)
	request_header = ngx.req.get_headers()
	method = ngx.req.get_method()
	ip = get_client_ip()
	ipn = arrip(ip)
	uri_request_args = ngx.req.get_uri_args()
	cycle = config['cc']['cycle']
	endtime = config['cc']['endtime']
	limit = config['cc']['limit']
	retry = config['retry']
	retry_time = config['retry_time']
	retry_cycle = config['retry_cycle']
	min_route()
	--return return_message(200,request_header['Referer'])
	site_cc = is_site_config('cc')
	if site_config[server_name] and site_cc then
		cycle = site_config[server_name]['cc']['cycle']
		endtime = site_config[server_name]['cc']['endtime']
		limit = site_config[server_name]['cc']['limit']
	end
	if site_config[server_name] then
		retry = site_config[server_name]['retry']
		retry_time = site_config[server_name]['retry_time']
		retry_cycle = site_config[server_name]['retry_cycle']
	end

	if ip_white() then return true end
	ip_black()
	if url_white() then return true end
	url_black()
	drop()
	drop_abroad()
	ret=reptile_entrance(request_header['user-agent'],get_client_ip())
	if ret == 2 then
		return false
	end
	user_agent()
	cc()
	set_inser_cc()
	cc_increase()
	url()
    --固定cms
    if method == "GET" then 
        local return_cms_str=return_cms(server_name)
        local get='get'
        if return_cms_str == '0' then
            referer()  
            cookie()
        else
            if return_cms_str ~= null and return_cms_str ~=0  then
                local cms_path=select_rule(cms_read_file(return_cms_str,get))
                cms_rules = select_rule_cms(json.decode(rules_cms_read_file(return_cms_str)))
                if arrlen(cms_path) ~= 0 then
                -- cms 特定规则
                    if cms_is_ngx_match(cms_rules,uri,ngx.req.get_uri_args(),cms_path) then 
                        write_log('get','regular')
                        return_html(config['get']['status'],get_html)
                        return true 
                    end

                    if cms_url_white(return_cms_str) then return true end
                    if return_cms_str ~=nil or return_cms_str ~=0 then
                        --return return_message(200,get)
                        if cms_rule(return_cms_str,get) then return true end
                    else
                        referer()
                        cookie()
                    end
                else
                    referer()
                    cookie()
                end
            else
                referer()
                cookie()
            end
        end
    end
    args()
	scan_black()
    if method == "POST" then
        ngx.req.read_body()
        request_args111 = ngx.req.get_post_args()
        if  request_args111 then
            local return_cms_str=return_cms(server_name)
            local get='post'
            if return_cms_str == '0' then
                cookie()
            else
                --if get_boundary() then return false end
                if return_cms_str ~= null  and return_cms_str ~= 0   then
                    local cms_path=select_rule(cms_read_file(return_cms_str,get))
                    cms_rules = select_rule_cms(json.decode(rules_cms_read_file(return_cms_str)))
                    if arrlen(cms_path) ~= 0 then
                        -- cms 特定规则
                        if cms_is_ngx_match(cms_rules,uri,request_args111,cms_path) then 
                            write_log('post','regular')
                            return_html(config['post']['status'],post_html)
                            return true
                        end
                        if cms_url_white(return_cms_str) then return true end
                        if return_cms_str ~=nil or return_cms_str ~=0 then
                            --return return_message(200,ngx.req.get_post_args())
                            if cms_rule_post(return_cms_str,get) then return true end
                        else
               
                            cookie()
                        end
                    else
                        cookie()
                    end
                else
                    cookie() 
                end
            end
        end
    end
    post()
    post_data_chekc()
	if site_config[server_name] then
		X_Forwarded()
		post_X_Forwarded()
		php_path()
		url_path()
		url_ext()
		url_rule_ex()
		url_tell()
		post_data()
	end
end