# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 黄文良 <287962566@qq.com>
# | Author: 梁凯强 <1249648969@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔网站防火墙
# +--------------------------------------------------------------------
import sys ,os #line:14
if sys .version_info [0 ]==2 :#line:15
    reload (sys )#line:16
    sys .setdefaultencoding ('utf-8')#line:17
os .chdir ('/www/server/panel')#line:18
sys .path .append ("class/")#line:19
import json ,os ,time ,public ,string ,math #line:20
if __name__ !='__main__':#line:22
    from panelAuth import panelAuth #line:23
    from BTPanel import session #line:24
class btwaf_httpd_main :#line:26
    __OO0OOOO0O0O0O0000 ='/www/server/btwaf/'#line:27
    __O00O00OOO000O0O00 ={True :'开启',False :'关闭',0 :'停用',1 :'启用'}#line:28
    __O0OO0OOOO0OOOO0O0 =None #line:29
    __OOOOO0OOOO00OO0OO =["args.json","cookie.json","post.json","url_white.json","url.json","user_agent.json"]#line:30
    setupPath ='/www/server'#line:31
    apachedefaultfile ="%s/apache/conf/extra/httpd-default.conf"%(setupPath )#line:32
    apachempmfile ="%s/apache/conf/extra/httpd-mpm.conf"%(setupPath )#line:33
    __OOO0O00OO00OOO000 ={"EcShop":["/ecshop/api/cron.php","/appserver/public/js/main.js","/ecshop/js/index.js","/ecshop/data/config.php"],"weiqin":["/framework/table/users.table.php","/payment/alipay/return.php","/web/common/bootstrap.sys.inc.php"],"haiyang":["/data/admin/ping.php","/js/history.js","/templets/default/html/topicindex.html"],"canzhi":["/system/module/action/js/history.js","/system/framework/base/control.class.php","/www/data/css/default_clean_en.css"],"pingguo":["/static/js/jquery.pngFix.js","/static/css/admin_style.css","/template/default_pc/js/jquery-autocomplete.js"],"PHPCMS":["/phpsso_server/statics/css/system.css","/phpcms/languages/en/cnzz.lang.php","/api/reg_send_sms.php"],"wordpress":["/wp-content/languages/admin-network-zh_CN.mo","/wp-includes/js/admin-bar.js","/wp-admin/css/colors/ocean/colors.css"],"zhimeng":["/include/calendar/calendar-win2k-1.css","/include/js/jquery/ui.tabs.js","/inc/inc_stat.php","/images/js/ui.core.js"],"Discuz":["/static/js/admincp.js","/api/javascript/javascript.php","/api/trade/notify_invite.php"],"metlnfo":["/admin/content/article/save.php","/app/system/column","/config/metinfo.inc.php"]}#line:51
    def get_zhizu_list (O00OO0OO00OO0000O ):#line:54
        O000OO00OOOOOOOO0 =public .httpGet ('http://www.bt.cn/api/panel/get_spider_type')#line:55
        if not O000OO00OOOOOOOO0 :return False #line:56
        public .WriteFile (O00OO0OO00OO0000O .__OO0OOOO0O0O0O0000 +'zhi.json',O000OO00OOOOOOOO0 )#line:57
        return json .loads (O000OO00OOOOOOOO0 )#line:58
    def stop (OOOO00OOO000OOOO0 ):#line:61
        ""#line:62
        OOOOO00000O00OOO0 =json .loads (public .readFile (OOOO00OOO000OOOO0 .__OO0OOOO0O0O0O0000 +'config.json'))#line:63
        OOOOO00000O00OOO0 ['open']=False #line:64
        OOOO00OOO000OOOO0 .__O0OO0O0OOOO0000OO (OOOOO00000O00OOO0 )#line:65
        # public .ExecShell ('rm -rf /www/server/btwaf && rm -rf /www/server/panel/plugin/btwaf_httpd')#line:66
        if os .path .exists ('/www/server/nginx/sbin/nginx'):#line:67
            OO00OOOO0O00O0OO0 =public .ExecShell ('/etc/init.d/nginx reload')#line:68
            if OO00OOOO0O00O0OO0 [1 ].find ('nginx.pid')!=-1 :#line:69
                public .ExecShell ('pkill -9 nginx && sleep 1');#line:70
                public .ExecShell ('/etc/init.d/nginx start');#line:71
        else :#line:72
            OO00OOOO0O00O0OO0 =public .ExecShell ('/etc/init.d/httpd reload')#line:73
    def get_zhizu_ip_list (O000OO000O0OOOO0O ):#line:78
        from BTPanel import session #line:79
        O0O0O00OO0O0000OO =O000OO000O0OOOO0O .get_zhizu_list ()#line:80
        if 'types'in O0O0O00OO0O0000OO :#line:81
            if len (O0O0O00OO0O0000OO ['types'])>=1 :#line:82
                for O00O000O0O0O000O0 in O0O0O00OO0O0000OO ['types']:#line:83
                    O00000000O0O0OOOO =public .httpGet ('http://www.bt.cn/api/panel/get_spider?spider=%s'%str (O00O000O0O0O000O0 ['id']))#line:84
                    if not O00000000O0O0OOOO :continue #line:85
                    try :#line:86
                        OO0O0OO0OOO0OO00O =json .dumps (O00000000O0O0OOOO )#line:87
                    except :#line:88
                        if not os .path .exists (O000OO000O0OOOO0O .__OO0OOOO0O0O0O0000 +str (O00O000O0O0O000O0 ['id'])+'.json'):#line:89
                            O00O00000OOO00O00 =[]#line:90
                            public .WriteFile (O000OO000O0OOOO0O .__OO0OOOO0O0O0O0000 +str (O00O000O0O0O000O0 ['id'])+'.json',json .dumps (O00O00000OOO00O00 ))#line:91
                        continue #line:92
                    if os .path .exists (O000OO000O0OOOO0O .__OO0OOOO0O0O0O0000 +str (O00O000O0O0O000O0 ['id'])+'.json'):#line:93
                        O0000O00O0O000O00 =public .ReadFile (O000OO000O0OOOO0O .__OO0OOOO0O0O0O0000 +str (O00O000O0O0O000O0 ['id'])+'.json')#line:94
                        if O0000O00O0O000O00 :#line:95
                            OO0O00O00OOO0O000 =list (set (json .loads (O0000O00O0O000O00 )).union (json .loads (O00000000O0O0OOOO )))#line:96
                            public .WriteFile (O000OO000O0OOOO0O .__OO0OOOO0O0O0O0000 +str (O00O000O0O0O000O0 ['id'])+'.json',json .dumps (OO0O00O00OOO0O000 ))#line:97
                            OO0O00000000OO0OO =list (set (json .loads (O0000O00O0O000O00 )).difference (set (json .loads (O00000000O0O0OOOO ))))#line:98
                            public .httpGet ('http://www.bt.cn/api/panel/add_spiders?address=%s'%json .dumps (OO0O00000000OO0OO ))#line:99
                        else :#line:100
                            public .WriteFile (O000OO000O0OOOO0O .__OO0OOOO0O0O0O0000 +str (O00O000O0O0O000O0 ['id'])+'.json',O00000000O0O0OOOO )#line:101
                    else :#line:102
                        public .WriteFile (O000OO000O0OOOO0O .__OO0OOOO0O0O0O0000 +str (O00O000O0O0O000O0 ['id'])+'.json',O00000000O0O0OOOO )#line:103
        if not 'zhizu'in session :session ['zhizu']=1 #line:104
        return True #line:105
    def get_zhizu_list22 (OOO00O0OOOO00O0OO ,OO0OOO0OO000O00OO ):#line:108
        O0000O0000O0O0OO0 =OOO00O0OOOO00O0OO .get_zhizu_list ()#line:109
        if 'types'in O0000O0000O0O0OO0 :#line:110
            if len (O0000O0000O0O0OO0 ['types'])>=1 :#line:111
                for OOO000O0O00O00O00 in O0000O0000O0O0OO0 ['types']:#line:112
                    OO00000000000OOOO =public .httpGet ('http://www.bt.cn/api/panel/get_spider?spider=%s'%str (OOO000O0O00O00O00 ['id']))#line:113
                    if not OO00000000000OOOO :continue #line:114
                    try :#line:115
                        OO0O0O00OOO00000O =json .dumps (OO00000000000OOOO )#line:116
                    except :#line:117
                        if not os .path .exists (OOO00O0OOOO00O0OO .__OO0OOOO0O0O0O0000 +str (OOO000O0O00O00O00 ['id'])+'.json'):#line:118
                            O00OO0O00OOOO0O0O =[]#line:119
                            public .WriteFile (OOO00O0OOOO00O0OO .__OO0OOOO0O0O0O0000 +str (OOO000O0O00O00O00 ['id'])+'.json',json .dumps (O00OO0O00OOOO0O0O ))#line:120
                        continue #line:121
                    if os .path .exists (OOO00O0OOOO00O0OO .__OO0OOOO0O0O0O0000 +str (OOO000O0O00O00O00 ['id'])+'.json'):#line:122
                        O0O0O0OO00000O00O =public .ReadFile (OOO00O0OOOO00O0OO .__OO0OOOO0O0O0O0000 +str (OOO000O0O00O00O00 ['id'])+'.json')#line:123
                        if O0O0O0OO00000O00O :#line:124
                            O00OO0O0OOOO0O0OO =list (set (json .loads (O0O0O0OO00000O00O )).union (json .loads (OO00000000000OOOO )))#line:125
                            public .WriteFile (OOO00O0OOOO00O0OO .__OO0OOOO0O0O0O0000 +str (OOO000O0O00O00O00 ['id'])+'.json',json .dumps (O00OO0O0OOOO0O0OO ))#line:126
                            O0OOOO000000000OO =list (set (json .loads (O0O0O0OO00000O00O )).difference (set (json .loads (OO00000000000OOOO ))))#line:127
                            if len (O0OOOO000000000OO )==0 :continue #line:128
                            OO00000000000OOOO =public .httpGet ('http://www.bt.cn/api/panel/add_spiders?address=%s'%json .dumps (O0OOOO000000000OO ),timeout =10 )#line:130
                        else :#line:132
                            public .WriteFile (OOO00O0OOOO00O0OO .__OO0OOOO0O0O0O0000 +str (OOO000O0O00O00O00 ['id'])+'.json',OO00000000000OOOO )#line:133
                    else :#line:134
                        public .WriteFile (OOO00O0OOOO00O0OO .__OO0OOOO0O0O0O0000 +str (OOO000O0O00O00O00 ['id'])+'.json',OO00000000000OOOO )#line:135
        return public .returnMsg (True ,'更新蜘蛛成功!')#line:137
    def start_zhuzu (OOOOO0000O0000000 ):#line:140
        O0OOOOOO00O00OO0O =OOOOO0000O0000000 .get_zhizu_list ()#line:142
        if 'types'in O0OOOOOO00O00OO0O :#line:143
            if len (O0OOOOOO00O00OO0O ['types'])>=1 :#line:144
                for O0000O00OO00O0OOO in O0OOOOOO00O00OO0O ['types']:#line:145
                    O0OO00OO0000OO000 =public .httpGet ('http://www.bt.cn/api/panel/get_spider?spider=%s'%str (O0000O00OO00O0OOO ['id']))#line:146
                    if not O0OO00OO0000OO000 :continue #line:147
                    try :#line:148
                        O0O000000O00O0000 =json .dumps (O0OO00OO0000OO000 )#line:149
                    except :#line:150
                        if not os .path .exists (OOOOO0000O0000000 .__OO0OOOO0O0O0O0000 +str (O0000O00OO00O0OOO ['id'])+'.json'):#line:151
                            OOOOO000O0OOO00O0 =[]#line:152
                            public .WriteFile (OOOOO0000O0000000 .__OO0OOOO0O0O0O0000 +str (O0000O00OO00O0OOO ['id'])+'.json',json .dumps (OOOOO000O0OOO00O0 ))#line:153
                        continue #line:154
                    if os .path .exists (OOOOO0000O0000000 .__OO0OOOO0O0O0O0000 +str (O0000O00OO00O0OOO ['id'])+'.json'):#line:155
                        O0OO000OO0O0OOOO0 =public .ReadFile (OOOOO0000O0000000 .__OO0OOOO0O0O0O0000 +str (O0000O00OO00O0OOO ['id'])+'.json')#line:156
                        if O0OO000OO0O0OOOO0 :#line:157
                            O0O0O0O0OOO000000 =list (set (json .loads (O0OO000OO0O0OOOO0 )).union (json .loads (O0OO00OO0000OO000 )))#line:158
                            public .WriteFile (OOOOO0000O0000000 .__OO0OOOO0O0O0O0000 +str (O0000O00OO00O0OOO ['id'])+'.json',json .dumps (O0O0O0O0OOO000000 ))#line:159
                            OOO0000OO0O0O00OO =list (set (json .loads (O0OO000OO0O0OOOO0 )).difference (set (json .loads (O0OO00OO0000OO000 ))))#line:160
                            print ('http://www.bt.cn/api/panel/add_spiders?address=%s'%json .dumps (OOO0000OO0O0O00OO ))#line:161
                            public .httpGet ('http://www.bt.cn/api/panel/add_spiders?address=%s'%json .dumps (OOO0000OO0O0O00OO ))#line:163
                        else :#line:164
                            public .WriteFile (OOOOO0000O0000000 .__OO0OOOO0O0O0O0000 +str (O0000O00OO00O0OOO ['id'])+'.json',O0OO00OO0000OO000 )#line:165
                    else :#line:166
                        public .WriteFile (OOOOO0000O0000000 .__OO0OOOO0O0O0O0000 +str (O0000O00OO00O0OOO ['id'])+'.json',O0OO00OO0000OO000 )#line:167
        return True #line:169
    def get_zhizu_ip (O0OO00O0O0OOOOOOO ,OO000O0OO00OOOOO0 ):#line:172
        O00O00O0O0OO0O0OO =O0OO00O0O0OOOOOOO .get_zhizu_list ()#line:173
        if 'types'in O00O00O0O0OO0O0OO :#line:174
            if len (O00O00O0O0OO0O0OO ['types'])>=1 :#line:175
                for OOO00O0O0O0O00O00 in O00O00O0O0OO0O0OO ['types']:#line:176
                    OOOO00OOOO0000O00 =public .httpGet ('http://www.bt.cn/api/panel/get_spider?spider=%s'%str (OOO00O0O0O0O00O00 ['id']))#line:177
                    if not OOOO00OOOO0000O00 :continue #line:178
                    try :#line:179
                        OO0O0O0O0O000O0OO =json .dumps (OOOO00OOOO0000O00 )#line:180
                    except :#line:181
                        if not os .path .exists (O0OO00O0O0OOOOOOO .__OO0OOOO0O0O0O0000 +str (OOO00O0O0O0O00O00 ['id'])+'.json'):#line:182
                            OOO0O0O000OOOOO00 =[]#line:183
                            public .WriteFile (O0OO00O0O0OOOOOOO .__OO0OOOO0O0O0O0000 +str (OOO00O0O0O0O00O00 ['id'])+'.json',json .dumps (OOO0O0O000OOOOO00 ))#line:184
                        continue #line:185
                    if os .path .exists (O0OO00O0O0OOOOOOO .__OO0OOOO0O0O0O0000 +str (OOO00O0O0O0O00O00 ['id'])+'.json'):#line:186
                        OO000OOO0000O0O0O =public .ReadFile (O0OO00O0O0OOOOOOO .__OO0OOOO0O0O0O0000 +str (OOO00O0O0O0O00O00 ['id'])+'.json')#line:187
                        if OO000OOO0000O0O0O :#line:188
                            OOOO0O0O0OO00O000 =list (set (json .loads (OO000OOO0000O0O0O )).union (json .loads (OOOO00OOOO0000O00 )))#line:189
                            public .WriteFile (O0OO00O0O0OOOOOOO .__OO0OOOO0O0O0O0000 +str (OOO00O0O0O0O00O00 ['id'])+'.json',json .dumps (OOOO0O0O0OO00O000 ))#line:190
                            OOOOO000OOOOO0000 =list (set (json .loads (OO000OOO0000O0O0O )).difference (set (json .loads (OOOO00OOOO0000O00 ))))#line:191
                            public .httpGet ('http://www.bt.cn/api/panel/add_spiders?address=%s'%json .dumps (OOOOO000OOOOO0000 ))#line:193
                        else :#line:194
                            public .WriteFile (O0OO00O0O0OOOOOOO .__OO0OOOO0O0O0O0000 +str (OOO00O0O0O0O00O00 ['id'])+'.json',json .dumps (OOOO00OOOO0000O00 ))#line:195
                    else :#line:196
                        public .WriteFile (O0OO00O0O0OOOOOOO .__OO0OOOO0O0O0O0000 +str (OOO00O0O0O0O00O00 ['id'])+'.json',json .dumps (OOOO00OOOO0000O00 ))#line:197
        return public .returnMsg (True ,'更新蜘蛛成功!')#line:199
    def Start_apache_cc (OO000O0OO0O00000O ,OO000O000O0000000 ):#line:202
        O0000OO00OOOO0000 =OO000O0OO0O00000O .auto_sync_apache ()#line:203
        return O0000OO00OOOO0000 #line:204
    def Get_apap_cc (OOOO00O0OOO000OOO ,O0O0O00O0O0OO0O00 ):#line:207
        OOOO0O000O0OOO000 =public .M ('crontab').where ('name=?',(u'Apache防火墙智能防御CC',)).getField ('id');#line:208
        if OOOO0O000O0OOO000 :return public .returnMsg (True ,'开启!');#line:209
        else :return public .returnMsg (False ,'关闭!');#line:210
    def Stop_apache_cc (O00O0OO0000000O00 ,OO00OO00OO000000O ):#line:214
        if os .path .exists ('/dev/shm/apache.txt'):#line:215
            os .remove ('/dev/shm/apache.txt')#line:216
        O0OOO0000O0OO0OO0 =public .M ('crontab').where ('name=?',(u'Apache防火墙智能防御CC',)).getField ('id');#line:217
        import crontab #line:218
        if O0OOO0000O0OO0OO0 :crontab .crontab ().DelCrontab ({'id':O0OOO0000O0OO0OO0 })#line:219
        return public .returnMsg (True ,'设置成功!');#line:220
    def auto_sync_apache (O00O000000O0OO0OO ):#line:223
        OO0OOO0OO00000O0O =public .M ('crontab').where ('name=?',(u'Apache防火墙智能防御CC',)).getField ('id');#line:224
        import crontab #line:225
        if OO0OOO0OO00000O0O :crontab .crontab ().DelCrontab ({'id':OO0OOO0OO00000O0O })#line:226
        O00OO0000O0000OO0 ={}#line:227
        O00OO0000O0000OO0 ['name']=u'Apache防火墙智能防御CC'#line:228
        O00OO0000O0000OO0 ['type']='minute-n'#line:229
        O00OO0000O0000OO0 ['where1']='1'#line:230
        O00OO0000O0000OO0 ['sBody']='python /www/server/panel/plugin/btwaf_httpd/btwaf_httpd_main.py start'#line:231
        O00OO0000O0000OO0 ['backupTo']='localhost'#line:232
        O00OO0000O0000OO0 ['sType']='toShell'#line:233
        O00OO0000O0000OO0 ['hour']=''#line:234
        O00OO0000O0000OO0 ['minute']=''#line:235
        O00OO0000O0000OO0 ['week']=''#line:236
        O00OO0000O0000OO0 ['sName']=''#line:237
        O00OO0000O0000OO0 ['urladdress']=''#line:238
        O00OO0000O0000OO0 ['save']=''#line:239
        crontab .crontab ().AddCrontab (O00OO0000O0000OO0 )#line:240
        return public .returnMsg (True ,'设置成功!');#line:241
    def retuen_apache (OO00O0000O000OO0O ):#line:245
            import re #line:246
            O0O0OO0OOO0O0OOOO =int (public .ExecShell ('cat /proc/cpuinfo |grep "processor"|wc -l')[0 ])#line:247
            OOO0O00000O0O00O0 =round (float (public .ExecShell ("ps aux|grep httpd|grep 'start'|awk '{cpusum += $3};END {print cpusum}'")[0 ])/O0O0OO0OOO0O0OOOO ,2 )#line:250
            public .ExecShell ("echo '%s'>/dev/shm/apache.txt"%int (OOO0O00000O0O00O0 ))#line:251
            return 'ok'#line:252
    def get_config (O00O00OO00000OO0O ,OOOOOO0O0OOO00OO0 ):#line:254
        if __name__ =="__main__":#line:255
            if not 'btwaf_httpd'in session :return [];#line:256
        O0O00OO0O00OO0OO0 =json .loads (public .readFile (O00O00OO00000OO0O .__OO0OOOO0O0O0O0000 +'config.json'));#line:257
        if not 'retry_cycle'in O0O00OO0O00OO0OO0 :#line:258
            O0O00OO0O00OO0OO0 ['retry_cycle']=60 ;#line:259
            O00O00OO00000OO0O .__O0OO0O0OOOO0000OO (O0O00OO0O00OO0OO0 );#line:260
        if O0O00OO0O00OO0OO0 ['start_time']==0 :#line:261
            O0O00OO0O00OO0OO0 ['start_time']=time .time ();#line:262
            O00O00OO00000OO0O .__O0OO0O0OOOO0000OO (O0O00OO0O00OO0OO0 );#line:263
        return O0O00OO0O00OO0OO0 #line:264
    def get_site_config (O0O000OO00OOO0O00 ,OO0OO0O000000O0O0 ):#line:266
        if __name__ =="__main__":#line:267
            if not 'btwaf_httpd'in session :return [];#line:268
        O000OOOO000OO0OO0 =public .readFile (O0O000OO00OOO0O00 .__OO0OOOO0O0O0O0000 +'site.json');#line:269
        O0O0O00OO000OO0OO =O0O000OO00OOO0O00 .__O0OOOO000OO0OO000 (json .loads (O000OOOO000OO0OO0 ))#line:270
        if OO0OO0O000000O0O0 :#line:271
            O000000O00000O0OO =O0O000OO00OOO0O00 .get_total (None )['sites']#line:272
            OOOO00O0000000000 =[]#line:273
            for OO00OOOO000OOOOOO in O0O0O00OO000OO0OO .keys ():#line:274
                if not OO00OOOO000OOOOOO in O000000O00000O0OO :O000000O00000O0OO [OO00OOOO000OOOOOO ]={}#line:275
                O0O0O00OO000OO0OO [OO00OOOO000OOOOOO ]['total']=O0O000OO00OOO0O00 .__OOOOO0OOO0OOO0OO0 (O000000O00000O0OO [OO00OOOO000OOOOOO ])#line:276
                O000O000O00OO0000 =O0O0O00OO000OO0OO [OO00OOOO000OOOOOO ];#line:277
                O000O000O00OO0000 ['siteName']=OO00OOOO000OOOOOO ;#line:278
                OOOO00O0000000000 .append (O000O000O00OO0000 );#line:279
            O0O0O00OO000OO0OO =sorted (OOOO00O0000000000 ,key =lambda O00000OO0O00OOO0O :O00000OO0O00OOO0O ['log_size'],reverse =True )#line:280
        return O0O0O00OO000OO0OO #line:281
    def get_site_config_byname (O0O0O0000O0O0O0OO ,O00OOOO0O0OO0000O ):#line:283
        OO0000000OOO0OOOO =O0O0O0000O0O0O0OO .get_site_config (None );#line:284
        OO0000OO00O0OO0OO =OO0000000OOO0OOOO [O00OOOO0O0OO0000O .siteName ]#line:285
        OO0000OO00O0OO0OO ['top']=O0O0O0000O0O0O0OO .get_config (None )#line:286
        return OO0000OO00O0OO0OO #line:287
    def set_open (OOOO0OOO00OO0OO00 ,OO0OO000O0O0OO00O ):#line:289
        O0O00OO00O0O0O0O0 =OOOO0OOO00OO0OO00 .get_config (None )#line:290
        if O0O00OO00O0O0O0O0 ['open']:#line:291
            O0O00OO00O0O0O0O0 ['open']=False #line:292
            O0O00OO00O0O0O0O0 ['start_time']=0 #line:293
        else :#line:294
            O0O00OO00O0O0O0O0 ['open']=True #line:295
            O0O00OO00O0O0O0O0 ['start_time']=int (time .time ())#line:296
        OOOO0OOO00OO0OO00 .__OO00OO0O0OOOOO000 (OOOO0OOO00OO0OO00 .__O00O00OOO000O0O00 [O0O00OO00O0O0O0O0 ['open']]+'网站防火墙(WAF)');#line:297
        OOOO0OOO00OO0OO00 .__O0OO0O0OOOO0000OO (O0O00OO00O0O0O0O0 )#line:298
        return public .returnMsg (True ,'设置成功!');#line:299
    def set_obj_open (OOOO000OOO0O00000 ,O00O0OO00O00O0000 ):#line:301
        OO0OOO0OO0O00O0O0 =OOOO000OOO0O00000 .get_config (None )#line:302
        if type (OO0OOO0OO0O00O0O0 [O00O0OO00O00O0000 .obj ])!=bool :#line:303
            if OO0OOO0OO0O00O0O0 [O00O0OO00O00O0000 .obj ]['open']:#line:304
                OO0OOO0OO0O00O0O0 [O00O0OO00O00O0000 .obj ]['open']=False #line:305
            else :#line:306
                OO0OOO0OO0O00O0O0 [O00O0OO00O00O0000 .obj ]['open']=True #line:307
            OOOO000OOO0O00000 .__OO00OO0O0OOOOO000 (OOOO000OOO0O00000 .__O00O00OOO000O0O00 [OO0OOO0OO0O00O0O0 [O00O0OO00O00O0000 .obj ]['open']]+'【'+O00O0OO00O00O0000 .obj +'】功能');#line:308
        else :#line:309
            if OO0OOO0OO0O00O0O0 [O00O0OO00O00O0000 .obj ]:#line:310
                OO0OOO0OO0O00O0O0 [O00O0OO00O00O0000 .obj ]=False #line:311
            else :#line:312
                OO0OOO0OO0O00O0O0 [O00O0OO00O00O0000 .obj ]=True #line:313
            OOOO000OOO0O00000 .__OO00OO0O0OOOOO000 (OOOO000OOO0O00000 .__O00O00OOO000O0O00 [OO0OOO0OO0O00O0O0 [O00O0OO00O00O0000 .obj ]]+'【'+O00O0OO00O00O0000 .obj +'】功能');#line:314
        OOOO000OOO0O00000 .__O0OO0O0OOOO0000OO (OO0OOO0OO0O00O0O0 )#line:316
        return public .returnMsg (True ,'设置成功!');#line:317
    def set_site_obj_open (O000O00O0OO000000 ,OOO0O0OOO0OOOOOOO ):#line:319
        O0O0O0OOOOOOO000O =O000O00O0OO000000 .get_site_config (None )#line:320
        if type (O0O0O0OOOOOOO000O [OOO0O0OOO0OOOOOOO .siteName ][OOO0O0OOO0OOOOOOO .obj ])!=bool :#line:321
            if O0O0O0OOOOOOO000O [OOO0O0OOO0OOOOOOO .siteName ][OOO0O0OOO0OOOOOOO .obj ]['open']:#line:322
                O0O0O0OOOOOOO000O [OOO0O0OOO0OOOOOOO .siteName ][OOO0O0OOO0OOOOOOO .obj ]['open']=False #line:323
            else :#line:324
                O0O0O0OOOOOOO000O [OOO0O0OOO0OOOOOOO .siteName ][OOO0O0OOO0OOOOOOO .obj ]['open']=True #line:325
            O000O00O0OO000000 .__OO00OO0O0OOOOO000 (O000O00O0OO000000 .__O00O00OOO000O0O00 [O0O0O0OOOOOOO000O [OOO0O0OOO0OOOOOOO .siteName ][OOO0O0OOO0OOOOOOO .obj ]['open']]+'网站【'+OOO0O0OOO0OOOOOOO .siteName +'】【'+OOO0O0OOO0OOOOOOO .obj +'】功能');#line:327
        else :#line:328
            if O0O0O0OOOOOOO000O [OOO0O0OOO0OOOOOOO .siteName ][OOO0O0OOO0OOOOOOO .obj ]:#line:329
                O0O0O0OOOOOOO000O [OOO0O0OOO0OOOOOOO .siteName ][OOO0O0OOO0OOOOOOO .obj ]=False #line:330
            else :#line:331
                O0O0O0OOOOOOO000O [OOO0O0OOO0OOOOOOO .siteName ][OOO0O0OOO0OOOOOOO .obj ]=True #line:332
            O000O00O0OO000000 .__OO00OO0O0OOOOO000 (O000O00O0OO000000 .__O00O00OOO000O0O00 [O0O0O0OOOOOOO000O [OOO0O0OOO0OOOOOOO .siteName ][OOO0O0OOO0OOOOOOO .obj ]]+'网站【'+OOO0O0OOO0OOOOOOO .siteName +'】【'+OOO0O0OOO0OOOOOOO .obj +'】功能');#line:334
        if OOO0O0OOO0OOOOOOO .obj =='drop_abroad':O000O00O0OO000000 .__O00O000O000000O0O ();#line:336
        O000O00O0OO000000 .__OOOOOO0OO00OOO0O0 (O0O0O0OOOOOOO000O )#line:337
        return public .returnMsg (True ,'设置成功!');#line:338
    def set_obj_status (OO0O0O0OO0O00O00O ,O00O00000O0O000O0 ):#line:340
        O00OOO000OO00O00O =OO0O0O0OO0O00O00O .get_config (None )#line:341
        O00OOO000OO00O00O [O00O00000O0O000O0 .obj ]['status']=int (O00O00000O0O000O0 .statusCode )#line:342
        OO0O0O0OO0O00O00O .__O0OO0O0OOOO0000OO (O00OOO000OO00O00O )#line:343
        return public .returnMsg (True ,'设置成功!');#line:344
    def set_cc_conf (O0O0O000OOO0O0O0O ,O00O000O0OOO00OO0 ):#line:346
        OOO0000OO000OOO0O =O0O0O000OOO0O0O0O .get_config (None )#line:347
        OOO0000OO000OOO0O ['cc']['cycle']=int (O00O000O0OOO00OO0 .cycle )#line:348
        OOO0000OO000OOO0O ['cc']['limit']=int (O00O000O0OOO00OO0 .limit )#line:349
        OOO0000OO000OOO0O ['cc']['endtime']=int (O00O000O0OOO00OO0 .endtime )#line:350
        OOO0000OO000OOO0O ['cc']['increase']=(O00O000O0OOO00OO0 .increase =='1')|False #line:351
        O0O0O000OOO0O0O0O .__O0OO0O0OOOO0000OO (OOO0000OO000OOO0O )#line:352
        O0O0O000OOO0O0O0O .__OO00OO0O0OOOOO000 ('设置全局CC配置为：'+O00O000O0OOO00OO0 .cycle +' 秒内累计请求超过 '+O00O000O0OOO00OO0 .limit +' 次后,封锁 '+O00O000O0OOO00OO0 .endtime +' 秒'+',增强:'+O00O000O0OOO00OO0 .increase );#line:354
        return public .returnMsg (True ,'设置成功!');#line:355
    def set_site_cc_conf (O0O000OO0OOOO0OOO ,O000OOOO0O0OO00OO ):#line:357
        OOO0000OOOO00OOO0 =O0O000OO0OOOO0OOO .get_site_config (None )#line:358
        OOO0000OOOO00OOO0 [O000OOOO0O0OO00OO .siteName ]['cc']['cycle']=int (O000OOOO0O0OO00OO .cycle )#line:359
        OOO0000OOOO00OOO0 [O000OOOO0O0OO00OO .siteName ]['cc']['limit']=int (O000OOOO0O0OO00OO .limit )#line:360
        OOO0000OOOO00OOO0 [O000OOOO0O0OO00OO .siteName ]['cc']['endtime']=int (O000OOOO0O0OO00OO .endtime )#line:361
        OOO0000OOOO00OOO0 [O000OOOO0O0OO00OO .siteName ]['cc']['increase']=(O000OOOO0O0OO00OO .increase =='1')|False #line:362
        O0O000OO0OOOO0OOO .__OOOOOO0OO00OOO0O0 (OOO0000OOOO00OOO0 )#line:363
        O0O000OO0OOOO0OOO .__OO00OO0O0OOOOO000 ('设置站点【'+O000OOOO0O0OO00OO .siteName +'】CC配置为：'+O000OOOO0O0OO00OO .cycle +' 秒内累计请求超过 '+O000OOOO0O0OO00OO .limit +' 次后,封锁 '+O000OOOO0O0OO00OO .endtime +' 秒'+',增强:'+O000OOOO0O0OO00OO .increase );#line:365
        return public .returnMsg (True ,'设置成功!');#line:366
    def add_cnip (OO0OO0OOOOO0OO00O ,OO0OOO0OO00OOO0O0 ):#line:368
        OO000O00O0000OO0O =[OO0OO0OOOOO0OO00O .__O0OO0OOO0O00O0000 (OO0OOO0OO00OOO0O0 .start_ip ),OO0OO0OOOOO0OO00O .__O0OO0OOO0O00O0000 (OO0OOO0OO00OOO0O0 .end_ip )]#line:369
        if not OO000O00O0000OO0O [0 ]or not OO000O00O0000OO0O [1 ]:return public .returnMsg (False ,'IP段格式不正确');#line:370
        if not OO0OO0OOOOO0OO00O .__OO0OOOO000OO0O00O (OO000O00O0000OO0O ):return public .returnMsg (False ,'起始IP不能大于结束IP');#line:371
        O0O00OO0OOOO0OOO0 =OO0OO0OOOOO0OO00O .__OOOOOOO0OOO00O00O ('cn')#line:372
        if OO000O00O0000OO0O in O0O00OO0OOOO0OOO0 :return public .returnMsg (False ,'指定IP段已存在!');#line:373
        O0O00OO0OOOO0OOO0 .insert (0 ,OO000O00O0000OO0O )#line:374
        OO0OO0OOOOO0OO00O .__O0OO000O0OOOO0000 ('cn',O0O00OO0OOOO0OOO0 )#line:375
        OO0OO0OOOOO0OO00O .__OO00OO0O0OOOOO000 ('添加IP段['+OO0OOO0OO00OOO0O0 .start_ip +'-'+OO0OOO0OO00OOO0O0 .end_ip +']到国内IP库');#line:376
        return public .returnMsg (True ,'添加成功!');#line:377
    def remove_cnip (O00O0000O000O0O00 ,O0OO00OOOOO0O00OO ):#line:379
        OOOOO00O0OO0000OO =int (O0OO00OOOOO0O00OO .index )#line:380
        OOOOOO0O0000OOO0O =O00O0000O000O0O00 .__OOOOOOO0OOO00O00O ('cn')#line:381
        O000O0OOOOO000O00 =OOOOOO0O0000OOO0O [OOOOO00O0OO0000OO ]#line:382
        del (OOOOOO0O0000OOO0O [OOOOO00O0OO0000OO ])#line:383
        O00O0000O000O0O00 .__O0OO000O0OOOO0000 ('cn',OOOOOO0O0000OOO0O )#line:384
        O00O0000O000O0O00 .__OO00OO0O0OOOOO000 ('从国内IP库删除['+'.'.join (map (str ,O000O0OOOOO000O00 [0 ]))+'-'+'.'.join (map (str ,O000O0OOOOO000O00 [1 ]))+']');#line:385
        return public .returnMsg (True ,'删除成功!');#line:386
    def add_ip_white (O0O0O00O00OO00O0O ,O0OOO0OO0O0O00O0O ):#line:388
        OOO0OO0OOOO0000O0 =[O0O0O00O00OO00O0O .__O0OO0OOO0O00O0000 (O0OOO0OO0O0O00O0O .start_ip ),O0O0O00O00OO00O0O .__O0OO0OOO0O00O0000 (O0OOO0OO0O0O00O0O .end_ip )]#line:389
        if not OOO0OO0OOOO0000O0 [0 ]or not OOO0OO0OOOO0000O0 [1 ]:return public .returnMsg (False ,'IP段格式不正确');#line:390
        if not O0O0O00O00OO00O0O .__OO0OOOO000OO0O00O (OOO0OO0OOOO0000O0 ):return public .returnMsg (False ,'起始IP不能大于结束IP');#line:391
        OOOOOOO000O000OOO =O0O0O00O00OO00O0O .__OOOOOOO0OOO00O00O ('ip_white')#line:392
        if OOO0OO0OOOO0000O0 in OOOOOOO000O000OOO :return public .returnMsg (False ,'指定IP段已存在!');#line:393
        OOOOOOO000O000OOO .insert (0 ,OOO0OO0OOOO0000O0 )#line:394
        O0O0O00O00OO00O0O .__O0OO000O0OOOO0000 ('ip_white',OOOOOOO000O000OOO )#line:395
        O0O0O00O00OO00O0O .__OO00OO0O0OOOOO000 ('添加IP段['+O0OOO0OO0O0O00O0O .start_ip +'-'+O0OOO0OO0O0O00O0O .end_ip +']到IP白名单');#line:396
        return public .returnMsg (True ,'添加成功!');#line:397
    def remove_ip_white (O0OOO0O00OOO0OO00 ,OO0O0000000O000OO ):#line:399
        OOO0O0OO0O000000O =int (OO0O0000000O000OO .index )#line:400
        OO00O0O000O0O0OO0 =O0OOO0O00OOO0OO00 .__OOOOOOO0OOO00O00O ('ip_white')#line:401
        OOO0OO00O00000O0O =OO00O0O000O0O0OO0 [OOO0O0OO0O000000O ]#line:402
        del (OO00O0O000O0O0OO0 [OOO0O0OO0O000000O ])#line:403
        O0OOO0O00OOO0OO00 .__O0OO000O0OOOO0000 ('ip_white',OO00O0O000O0O0OO0 )#line:404
        O0OOO0O00OOO0OO00 .__OO00OO0O0OOOOO000 ('从IP白名单删除['+'.'.join (map (str ,OOO0OO00O00000O0O [0 ]))+'-'+'.'.join (map (str ,OOO0OO00O00000O0O [1 ]))+']');#line:405
        return public .returnMsg (True ,'删除成功!');#line:406
    def add_ip_black (O00OO0OO0OO000OO0 ,OO0OOOOO0OOOO0O0O ):#line:408
        OOO0O0OO0O00O00O0 =[O00OO0OO0OO000OO0 .__O0OO0OOO0O00O0000 (OO0OOOOO0OOOO0O0O .start_ip ),O00OO0OO0OO000OO0 .__O0OO0OOO0O00O0000 (OO0OOOOO0OOOO0O0O .end_ip )]#line:409
        if not OOO0O0OO0O00O00O0 [0 ]or not OOO0O0OO0O00O00O0 [1 ]:return public .returnMsg (False ,'IP段格式不正确');#line:410
        if not O00OO0OO0OO000OO0 .__OO0OOOO000OO0O00O (OOO0O0OO0O00O00O0 ):return public .returnMsg (False ,'起始IP不能大于结束IP');#line:411
        OOO0O00OOO0O0OO0O =O00OO0OO0OO000OO0 .__OOOOOOO0OOO00O00O ('ip_black')#line:412
        if OOO0O0OO0O00O00O0 in OOO0O00OOO0O0OO0O :return public .returnMsg (False ,'指定IP段已存在!');#line:413
        OOO0O00OOO0O0OO0O .insert (0 ,OOO0O0OO0O00O00O0 )#line:414
        O00OO0OO0OO000OO0 .__O0OO000O0OOOO0000 ('ip_black',OOO0O00OOO0O0OO0O )#line:415
        O00OO0OO0OO000OO0 .__OO00OO0O0OOOOO000 ('添加IP段['+OO0OOOOO0OOOO0O0O .start_ip +'-'+OO0OOOOO0OOOO0O0O .end_ip +']到IP黑名单');#line:416
        return public .returnMsg (True ,'添加成功!');#line:417
    def remove_ip_black (OO000OOOO000O000O ,O0000O000O00O0O00 ):#line:419
        O0O00OOOO0O00O00O =int (O0000O000O00O0O00 .index )#line:420
        O000OO0O00OO000O0 =OO000OOOO000O000O .__OOOOOOO0OOO00O00O ('ip_black')#line:421
        OOO0O0O0OO0O0000O =O000OO0O00OO000O0 [O0O00OOOO0O00O00O ]#line:422
        del (O000OO0O00OO000O0 [O0O00OOOO0O00O00O ])#line:423
        OO000OOOO000O000O .__O0OO000O0OOOO0000 ('ip_black',O000OO0O00OO000O0 )#line:424
        OO000OOOO000O000O .__OO00OO0O0OOOOO000 ('从IP黑名单删除['+'.'.join (map (str ,OOO0O0O0OO0O0000O [0 ]))+'-'+'.'.join (map (str ,OOO0O0O0OO0O0000O [1 ]))+']');#line:425
        return public .returnMsg (True ,'删除成功!');#line:426
    def add_url_white (O0000OO0000O0OO0O ,OOO00OOO0000000O0 ):#line:428
        OOO0OOOO0OOO000OO =O0000OO0000O0OO0O .__OOOOOOO0OOO00O00O ('url_white')#line:429
        OOO00OOO0000OO0O0 =OOO00OOO0000000O0 .url_rule .strip ()#line:430
        if OOO00OOO0000000O0 .url_rule in OOO0OOOO0OOO000OO :return public .returnMsg (False ,'您添加的URL已存在')#line:431
        OOO0OOOO0OOO000OO .insert (0 ,OOO00OOO0000OO0O0 )#line:432
        O0000OO0000O0OO0O .__O0OO000O0OOOO0000 ('url_white',OOO0OOOO0OOO000OO )#line:433
        O0000OO0000O0OO0O .__OO00OO0O0OOOOO000 ('添加url规则['+OOO00OOO0000OO0O0 +']到URL白名单');#line:434
        return public .returnMsg (True ,'添加成功!');#line:435
    def remove_url_white (OO0O000O00O0OO00O ,O000OO0O000O000OO ):#line:437
        OOO0OO0O0OO00OO00 =OO0O000O00O0OO00O .__OOOOOOO0OOO00O00O ('url_white')#line:438
        OO00O0OO000O0OOO0 =int (O000OO0O000O000OO .index )#line:439
        OO0OO0OO0000OO000 =OOO0OO0O0OO00OO00 [OO00O0OO000O0OOO0 ]#line:440
        del (OOO0OO0O0OO00OO00 [OO00O0OO000O0OOO0 ])#line:441
        OO0O000O00O0OO00O .__O0OO000O0OOOO0000 ('url_white',OOO0OO0O0OO00OO00 )#line:442
        OO0O000O00O0OO00O .__OO00OO0O0OOOOO000 ('从URL白名单删除URL规则['+OO0OO0OO0000OO000 +']');#line:443
        return public .returnMsg (True ,'删除成功!');#line:444
    def add_url_black (OO0O00O0O00O00OOO ,O000OOO0O0O0O0OOO ):#line:446
        OOOO00O00O0OOO00O =OO0O00O0O00O00OOO .__OOOOOOO0OOO00O00O ('url_black')#line:447
        O0000O0O000O0OO00 =O000OOO0O0O0O0OOO .url_rule .strip ()#line:448
        if O000OOO0O0O0O0OOO .url_rule in OOOO00O00O0OOO00O :return public .returnMsg (False ,'您添加的URL已存在')#line:449
        OOOO00O00O0OOO00O .insert (0 ,O0000O0O000O0OO00 )#line:450
        OO0O00O0O00O00OOO .__O0OO000O0OOOO0000 ('url_black',OOOO00O00O0OOO00O )#line:451
        OO0O00O0O00O00OOO .__OO00OO0O0OOOOO000 ('添加url规则['+O0000O0O000O0OO00 +']到URL黑名单');#line:452
        return public .returnMsg (True ,'添加成功!');#line:453
    def remove_url_black (O000OO0OOO00O0O00 ,O000OOO0O0OO000O0 ):#line:455
        O0OO0OOO0O0O00OOO =O000OO0OOO00O0O00 .__OOOOOOO0OOO00O00O ('url_black')#line:456
        OO0OOO00OOOO00OO0 =int (O000OOO0O0OO000O0 .index )#line:457
        O0O00OO0O0O00OOO0 =O0OO0OOO0O0O00OOO [OO0OOO00OOOO00OO0 ]#line:458
        del (O0OO0OOO0O0O00OOO [OO0OOO00OOOO00OO0 ])#line:459
        O000OO0OOO00O0O00 .__O0OO000O0OOOO0000 ('url_black',O0OO0OOO0O0O00OOO )#line:460
        O000OO0OOO00O0O00 .__OO00OO0O0OOOOO000 ('从URL黑名单删除URL规则['+O0O00OO0O0O00OOO0 +']');#line:461
        return public .returnMsg (True ,'删除成功!');#line:462
    def save_scan_rule (OO0000O0O0O0O0OOO ,O0000O0000O0OO0O0 ):#line:464
        OOO0O000O0OO0OO0O ={'header':O0000O0000O0OO0O0 .header ,'cookie':O0000O0000O0OO0O0 .cookie ,'args':O0000O0000O0OO0O0 .args }#line:465
        OO0000O0O0O0O0OOO .__O0OO000O0OOOO0000 ('scan_black',OOO0O000O0OO0OO0O )#line:466
        OO0000O0O0O0O0OOO .__OO00OO0O0OOOOO000 ('修改扫描器过滤规则');#line:467
        return public .returnMsg (True ,'设置成功')#line:468
    def set_retry (OOOO0OO0OOOOOOO0O ,O0000O000OO00O0O0 ):#line:470
        O0O000O0OOOOO0OO0 =OOOO0OO0OOOOOOO0O .get_config (None )#line:471
        O0O000O0OOOOO0OO0 ['retry']=int (O0000O000OO00O0O0 .retry )#line:472
        O0O000O0OOOOO0OO0 ['retry_cycle']=int (O0000O000OO00O0O0 .retry_cycle )#line:473
        O0O000O0OOOOO0OO0 ['retry_time']=int (O0000O000OO00O0O0 .retry_time )#line:474
        OOOO0OO0OOOOOOO0O .__O0OO0O0OOOO0000OO (O0O000O0OOOOO0OO0 )#line:475
        OOOO0OO0OOOOOOO0O .__OO00OO0O0OOOOO000 ('设置非法请求容忍阈值: '+O0000O000OO00O0O0 .retry_cycle +' 秒内累计超过 '+O0000O000OO00O0O0 .retry +' 次, 封锁 '+O0000O000OO00O0O0 .retry_time +' 秒');#line:476
        return public .returnMsg (True ,'设置成功!');#line:477
    def set_site_retry (OO0O0OOO0OO0OOOO0 ,OO000O0OOOOOOOO0O ):#line:479
        OO00O0O0OO0O0OOO0 =OO0O0OOO0OO0OOOO0 .get_site_config (None )#line:480
        OO00O0O0OO0O0OOO0 [OO000O0OOOOOOOO0O .siteName ]['retry']=int (OO000O0OOOOOOOO0O .retry )#line:481
        OO00O0O0OO0O0OOO0 [OO000O0OOOOOOOO0O .siteName ]['retry_cycle']=int (OO000O0OOOOOOOO0O .retry_cycle )#line:482
        OO00O0O0OO0O0OOO0 [OO000O0OOOOOOOO0O .siteName ]['retry_time']=int (OO000O0OOOOOOOO0O .retry_time )#line:483
        OO0O0OOO0OO0OOOO0 .__OOOOOO0OO00OOO0O0 (OO00O0O0OO0O0OOO0 )#line:484
        OO0O0OOO0OO0OOOO0 .__OO00OO0O0OOOOO000 ('设置网站【'+OO000O0OOOOOOOO0O .siteName +'】非法请求容忍阈值: '+OO000O0OOOOOOOO0O .retry_cycle +' 秒内累计超过 '+OO000O0OOOOOOOO0O .retry +' 次, 封锁 '+OO000O0OOOOOOOO0O .retry_time +' 秒');#line:486
        return public .returnMsg (True ,'设置成功!');#line:487
    def set_site_cdn_state (O0OOO0OO0O00O0O0O ,OOOO0OO0OO0O0O0OO ):#line:489
        O0O0O0OOOO000OO00 =O0OOO0OO0O00O0O0O .get_site_config (None )#line:490
        if O0O0O0OOOO000OO00 [OOOO0OO0OO0O0O0OO .siteName ]['cdn']:#line:491
            O0O0O0OOOO000OO00 [OOOO0OO0OO0O0O0OO .siteName ]['cdn']=False #line:492
        else :#line:493
            O0O0O0OOOO000OO00 [OOOO0OO0OO0O0O0OO .siteName ]['cdn']=True #line:494
        O0OOO0OO0O00O0O0O .__OOOOOO0OO00OOO0O0 (O0O0O0OOOO000OO00 )#line:495
        O0OOO0OO0O00O0O0O .__OO00OO0O0OOOOO000 (O0OOO0OO0O00O0O0O .__O00O00OOO000O0O00 [O0O0O0OOOO000OO00 [OOOO0OO0OO0O0O0OO .siteName ]['cdn']]+'站点【'+OOOO0OO0OO0O0O0OO .siteName +'】CDN模式');#line:496
        return public .returnMsg (True ,'设置成功!');#line:497
    def get_site_cdn_header (OOOO000OOO000O00O ,OO000O000OO0OOOOO ):#line:499
        OO00O0000OO00OO0O =OOOO000OOO000O00O .get_site_config (None )#line:500
        return OO00O0000OO00OO0O [OO000O000OO0OOOOO .siteName ]['cdn_header']#line:501
    def add_site_cdn_header (O0000OOO00O00OOOO ,OOO0O00O0OO000O0O ):#line:503
        O000O0O0O00O0OOO0 =O0000OOO00O00OOOO .get_site_config (None )#line:504
        OOO0O00O0OO000O0O .cdn_header =OOO0O00O0OO000O0O .cdn_header .strip ().lower ();#line:505
        if OOO0O00O0OO000O0O .cdn_header in O000O0O0O00O0OOO0 [OOO0O00O0OO000O0O .siteName ]['cdn_header']:return public .returnMsg (False ,'您添加的请求头已存在!');#line:506
        O000O0O0O00O0OOO0 [OOO0O00O0OO000O0O .siteName ]['cdn_header'].append (OOO0O00O0OO000O0O .cdn_header )#line:507
        O0000OOO00O00OOOO .__OOOOOO0OO00OOO0O0 (O000O0O0O00O0OOO0 )#line:508
        O0000OOO00O00OOOO .__OO00OO0O0OOOOO000 ('添加站点【'+OOO0O00O0OO000O0O .siteName +'】CDN-Header【'+OOO0O00O0OO000O0O .cdn_header +'】');#line:509
        return public .returnMsg (True ,'添加成功!');#line:510
    def remove_site_cdn_header (OO0000OO000000O0O ,O0OO00OOOO0O0O00O ):#line:512
        OO0OOO00OOOOO00O0 =OO0000OO000000O0O .get_site_config (None )#line:513
        O0OO00OOOO0O0O00O .cdn_header =O0OO00OOOO0O0O00O .cdn_header .strip ().lower ();#line:514
        if not O0OO00OOOO0O0O00O .cdn_header in OO0OOO00OOOOO00O0 [O0OO00OOOO0O0O00O .siteName ]['cdn_header']:return public .returnMsg (False ,'指定请求头不存在!');#line:515
        for OOOOOO0OOO0O0O000 in range (len (OO0OOO00OOOOO00O0 [O0OO00OOOO0O0O00O .siteName ]['cdn_header'])):#line:516
            if O0OO00OOOO0O0O00O .cdn_header ==OO0OOO00OOOOO00O0 [O0OO00OOOO0O0O00O .siteName ]['cdn_header'][OOOOOO0OOO0O0O000 ]:#line:517
                OO0000OO000000O0O .__OO00OO0O0OOOOO000 ('删除站点【'+O0OO00OOOO0O0O00O .siteName +'】CDN-Header【'+OO0OOO00OOOOO00O0 [O0OO00OOOO0O0O00O .siteName ]['cdn_header'][OOOOOO0OOO0O0O000 ]+'】');#line:519
                del (OO0OOO00OOOOO00O0 [O0OO00OOOO0O0O00O .siteName ]['cdn_header'][OOOOOO0OOO0O0O000 ])#line:520
                break ;#line:521
        OO0000OO000000O0O .__OOOOOO0OO00OOO0O0 (OO0OOO00OOOOO00O0 )#line:522
        return public .returnMsg (True ,'删除成功!');#line:523
    def get_site_rule (OOOO00000O000O000 ,O0O0O0OO0O0O0OOOO ):#line:525
        O0OO0O00O0OO000OO =OOOO00000O000O000 .get_site_config (None )#line:526
        return O0OO0O00O0OO000OO [O0O0O0OO0O0O0OOOO .siteName ][O0O0O0OO0O0O0OOOO .ruleName ]#line:527
    def add_site_rule (OO00000O0OO00O0OO ,O0OOOO0OO0OO000OO ):#line:529
        OOOOO000O0O0OO0OO =OO00000O0OO00O0OO .get_site_config (None )#line:530
        if not O0OOOO0OO0OO000OO .ruleName in OOOOO000O0O0OO0OO [O0OOOO0OO0OO000OO .siteName ]:return public .returnMsg (False ,'指定规则不存在!');#line:531
        OO0O000OO00OOOOOO =type (OOOOO000O0O0OO0OO [O0OOOO0OO0OO000OO .siteName ][O0OOOO0OO0OO000OO .ruleName ])#line:532
        if OO0O000OO00OOOOOO ==bool :return public .returnMsg (False ,'指定规则不存在!');#line:533
        if OO0O000OO00OOOOOO ==str :OOOOO000O0O0OO0OO [O0OOOO0OO0OO000OO .siteName ][O0OOOO0OO0OO000OO .ruleName ]=O0OOOO0OO0OO000OO .ruleValue #line:534
        if OO0O000OO00OOOOOO ==list :#line:535
            if O0OOOO0OO0OO000OO .ruleName =='url_rule'or O0OOOO0OO0OO000OO .ruleName =='url_tell':#line:536
                for O00O0OO0O0OO0000O in OOOOO000O0O0OO0OO [O0OOOO0OO0OO000OO .siteName ][O0OOOO0OO0OO000OO .ruleName ]:#line:537
                    if O00O0OO0O0OO0000O [0 ]==O0OOOO0OO0OO000OO .ruleUri :return public .returnMsg (False ,'指定URI已存在!');#line:538
                OOOO0O00O00OOOOO0 =[]#line:539
                OOOO0O00O00OOOOO0 .append (O0OOOO0OO0OO000OO .ruleUri )#line:540
                OOOO0O00O00OOOOO0 .append (O0OOOO0OO0OO000OO .ruleValue )#line:541
                if O0OOOO0OO0OO000OO .ruleName =='url_tell':#line:542
                    OO00000O0OO00O0OO .__OO00OO0O0OOOOO000 ('添加站点【'+O0OOOO0OO0OO000OO .siteName +'】URI【'+O0OOOO0OO0OO000OO .ruleUri +'】保护规则,参数【'+O0OOOO0OO0OO000OO .ruleValue +'】,参数值【'+O0OOOO0OO0OO000OO .rulePass +'】');#line:544
                    OOOO0O00O00OOOOO0 .append (O0OOOO0OO0OO000OO .rulePass )#line:545
                else :#line:546
                    OO00000O0OO00O0OO .__OO00OO0O0OOOOO000 ('添加站点【'+O0OOOO0OO0OO000OO .siteName +'】URI【'+O0OOOO0OO0OO000OO .ruleUri +'】过滤规则【'+O0OOOO0OO0OO000OO .ruleValue +'】');#line:547
                OOOOO000O0O0OO0OO [O0OOOO0OO0OO000OO .siteName ][O0OOOO0OO0OO000OO .ruleName ].insert (0 ,OOOO0O00O00OOOOO0 )#line:548
            else :#line:549
                if O0OOOO0OO0OO000OO .ruleValue in OOOOO000O0O0OO0OO [O0OOOO0OO0OO000OO .siteName ][O0OOOO0OO0OO000OO .ruleName ]:return public .returnMsg (False ,'指定规则已存在!');#line:550
                OOOOO000O0O0OO0OO [O0OOOO0OO0OO000OO .siteName ][O0OOOO0OO0OO000OO .ruleName ].insert (0 ,O0OOOO0OO0OO000OO .ruleValue )#line:551
                OO00000O0OO00O0OO .__OO00OO0O0OOOOO000 ('添加站点【'+O0OOOO0OO0OO000OO .siteName +'】【'+O0OOOO0OO0OO000OO .ruleName +'】过滤规则【'+O0OOOO0OO0OO000OO .ruleValue +'】');#line:552
        OO00000O0OO00O0OO .__OOOOOO0OO00OOO0O0 (OOOOO000O0O0OO0OO )#line:553
        return public .returnMsg (True ,'添加成功!');#line:554
    def remove_site_rule (O0O000OOOO0000O00 ,OO000OOO0OOO00OO0 ):#line:556
        OOOOOOO0000000O0O =O0O000OOOO0000O00 .get_site_config (None )#line:557
        O000O0000OO0O0O00 =int (OO000OOO0OOO00OO0 .index )#line:558
        if not OO000OOO0OOO00OO0 .ruleName in OOOOOOO0000000O0O [OO000OOO0OOO00OO0 .siteName ]:return public .returnMsg (False ,'指定规则不存在!');#line:559
        OO0OO00000OOO00OO =OOOOOOO0000000O0O [OO000OOO0OOO00OO0 .siteName ][OO000OOO0OOO00OO0 .ruleName ][O000O0000OO0O0O00 ]#line:560
        del (OOOOOOO0000000O0O [OO000OOO0OOO00OO0 .siteName ][OO000OOO0OOO00OO0 .ruleName ][O000O0000OO0O0O00 ])#line:561
        O0O000OOOO0000O00 .__OOOOOO0OO00OOO0O0 (OOOOOOO0000000O0O )#line:562
        O0O000OOOO0000O00 .__OO00OO0O0OOOOO000 ('删除站点【'+OO000OOO0OOO00OO0 .siteName +'】【'+OO000OOO0OOO00OO0 .ruleName +'】过滤规则【'+json .dumps (OO0OO00000OOO00OO )+'】');#line:563
        return public .returnMsg (True ,'删除成功!');#line:564
    def get_rule (OOO0OO0OO0OO00O0O ,O0OOO0OOOO0O0O000 ):#line:566
        O0O00OOOOOOOO0OOO =OOO0OO0OO0OO00O0O .__OOOOOOO0OOO00O00O (O0OOO0OOOO0O0O000 .ruleName )#line:567
        if not O0O00OOOOOOOO0OOO :return [];#line:568
        return O0O00OOOOOOOO0OOO #line:569
    def add_rule (OO0OO0OOO0O00O0O0 ,OO0O00O0OOO0O000O ):#line:571
        O00OOOOO0OOO0OO00 =OO0OO0OOO0O00O0O0 .__OOOOOOO0OOO00O00O (OO0O00O0OOO0O000O .ruleName )#line:572
        OOOOOOO000O0O0000 =[1 ,OO0O00O0OOO0O000O .ruleValue .strip (),OO0O00O0OOO0O000O .ps ,1 ]#line:573
        for OO0OOO00OOO0O0OOO in O00OOOOO0OOO0OO00 :#line:574
            if OO0OOO00OOO0O0OOO [1 ]==OOOOOOO000O0O0000 [1 ]:return public .returnMsg (False ,'指定规则已存在，请勿重复添加');#line:575
        O00OOOOO0OOO0OO00 .append (OOOOOOO000O0O0000 )#line:576
        OO0OO0OOO0O00O0O0 .__O0OO000O0OOOO0000 (OO0O00O0OOO0O000O .ruleName ,O00OOOOO0OOO0OO00 )#line:577
        OO0OO0OOO0O00O0O0 .__OO00OO0O0OOOOO000 ('添加全局规则【'+OO0O00O0OOO0O000O .ruleName +'】【'+OO0O00O0OOO0O000O .ps +'】');#line:578
        return public .returnMsg (True ,'添加成功!');#line:579
    def remove_rule (OOO000OO0O00OOO0O ,O0OOOO00000O0OOOO ):#line:581
        OO0OOOOO0O000000O =OOO000OO0O00OOO0O .__OOOOOOO0OOO00O00O (O0OOOO00000O0OOOO .ruleName )#line:582
        O00000OO00O0O0OO0 =int (O0OOOO00000O0OOOO .index )#line:583
        OO0O0OOOOO000OO0O =OO0OOOOO0O000000O [O00000OO00O0O0OO0 ][2 ]#line:584
        del (OO0OOOOO0O000000O [O00000OO00O0O0OO0 ])#line:585
        OOO000OO0O00OOO0O .__O0OO000O0OOOO0000 (O0OOOO00000O0OOOO .ruleName ,OO0OOOOO0O000000O )#line:586
        OOO000OO0O00OOO0O .__OO00OO0O0OOOOO000 ('删除全局规则【'+O0OOOO00000O0OOOO .ruleName +'】【'+OO0O0OOOOO000OO0O +'】');#line:587
        return public .returnMsg (True ,'删除成功!');#line:588
    def modify_rule (O0OOOOO0000000O00 ,O0O0O0O00OO0O0O0O ):#line:590
        O0OO00OOO00O000O0 =O0OOOOO0000000O00 .__OOOOOOO0OOO00O00O (O0O0O0O00OO0O0O0O .ruleName )#line:591
        OO0OO000OO0O0OOO0 =int (O0O0O0O00OO0O0O0O .index )#line:592
        O0OO00OOO00O000O0 [OO0OO000OO0O0OOO0 ][1 ]=O0O0O0O00OO0O0O0O .ruleBody #line:593
        O0OO00OOO00O000O0 [OO0OO000OO0O0OOO0 ][2 ]=O0O0O0O00OO0O0O0O .rulePs #line:594
        O0OOOOO0000000O00 .__O0OO000O0OOOO0000 (O0O0O0O00OO0O0O0O .ruleName ,O0OO00OOO00O000O0 )#line:595
        O0OOOOO0000000O00 .__OO00OO0O0OOOOO000 ('修改全局规则【'+O0O0O0O00OO0O0O0O .ruleName +'】【'+O0O0O0O00OO0O0O0O .rulePs +'】');#line:596
        return public .returnMsg (True ,'修改成功!');#line:597
    def set_rule_state (O00OOOO0OO0OOOO00 ,OO0O0OO000OOOOOOO ):#line:599
        OO00OO00O0000OO00 =O00OOOO0OO0OOOO00 .__OOOOOOO0OOO00O00O (OO0O0OO000OOOOOOO .ruleName )#line:600
        O000O00OOO0OOOOO0 =int (OO0O0OO000OOOOOOO .index )#line:601
        if OO00OO00O0000OO00 [O000O00OOO0OOOOO0 ][0 ]==0 :#line:602
            OO00OO00O0000OO00 [O000O00OOO0OOOOO0 ][0 ]=1 ;#line:603
        else :#line:604
            OO00OO00O0000OO00 [O000O00OOO0OOOOO0 ][0 ]=0 ;#line:605
        O00OOOO0OO0OOOO00 .__O0OO000O0OOOO0000 (OO0O0OO000OOOOOOO .ruleName ,OO00OO00O0000OO00 )#line:606
        O00OOOO0OO0OOOO00 .__OO00OO0O0OOOOO000 (O00OOOO0OO0OOOO00 .__O00O00OOO000O0O00 [OO00OO00O0000OO00 [O000O00OOO0OOOOO0 ][0 ]]+'全局规则【'+OO0O0OO000OOOOOOO .ruleName +'】【'+OO00OO00O0000OO00 [O000O00OOO0OOOOO0 ][2 ]+'】');#line:607
        return public .returnMsg (True ,'设置成功!');#line:608
    def get_site_disable_rule (O00O0OOO0O00O0O0O ,OOO0O00OOO000000O ):#line:610
        O0OOOOOO0O0O00OO0 =O00O0OOO0O00O0O0O .__OOOOOOO0OOO00O00O (OOO0O00OOO000000O .ruleName )#line:611
        O00OOOO000O0O0OOO =O00O0OOO0O00O0O0O .get_site_config (None )#line:612
        OO0OOOOOOOOO000O0 =O00OOOO000O0O0OOO [OOO0O00OOO000000O .siteName ]['disable_rule'][OOO0O00OOO000000O .ruleName ]#line:613
        for O000O0OOOO00OOO00 in range (len (O0OOOOOO0O0O00OO0 )):#line:614
            if O0OOOOOO0O0O00OO0 [O000O0OOOO00OOO00 ][0 ]==0 :O0OOOOOO0O0O00OO0 [O000O0OOOO00OOO00 ][0 ]=-1 ;#line:615
            if O000O0OOOO00OOO00 in OO0OOOOOOOOO000O0 :O0OOOOOO0O0O00OO0 [O000O0OOOO00OOO00 ][0 ]=0 ;#line:616
        return O0OOOOOO0O0O00OO0 ;#line:617
    def set_site_disable_rule (O000OOOO00OO0O0O0 ,O0O0OOOOO0OO0OOOO ):#line:619
        O00O000O0O000OO0O =O000OOOO00OO0O0O0 .get_site_config (None )#line:620
        O00OO0OOO000OOO0O =int (O0O0OOOOO0OO0OOOO .index )#line:621
        if O00OO0OOO000OOO0O in O00O000O0O000OO0O [O0O0OOOOO0OO0OOOO .siteName ]['disable_rule'][O0O0OOOOO0OO0OOOO .ruleName ]:#line:622
            for O0OO000O00OO0O0O0 in range (len (O00O000O0O000OO0O [O0O0OOOOO0OO0OOOO .siteName ]['disable_rule'][O0O0OOOOO0OO0OOOO .ruleName ])):#line:623
                if O00OO0OOO000OOO0O ==O00O000O0O000OO0O [O0O0OOOOO0OO0OOOO .siteName ]['disable_rule'][O0O0OOOOO0OO0OOOO .ruleName ][O0OO000O00OO0O0O0 ]:#line:624
                    del (O00O000O0O000OO0O [O0O0OOOOO0OO0OOOO .siteName ]['disable_rule'][O0O0OOOOO0OO0OOOO .ruleName ][O0OO000O00OO0O0O0 ])#line:625
                    break #line:626
        else :#line:627
            O00O000O0O000OO0O [O0O0OOOOO0OO0OOOO .siteName ]['disable_rule'][O0O0OOOOO0OO0OOOO .ruleName ].append (O00OO0OOO000OOO0O )#line:628
        O000OOOO00OO0O0O0 .__OO00OO0O0OOOOO000 ('设置站点【'+O0O0OOOOO0OO0OOOO .siteName +'】应用规则【'+O0O0OOOOO0OO0OOOO .ruleName +'】状态');#line:629
        O000OOOO00OO0O0O0 .__OOOOOO0OO00OOO0O0 (O00O000O0O000OO0O )#line:630
        return public .returnMsg (True ,'设置成功!');#line:631
    def get_safe_logs (OOOO00OO000O0O00O ,OO000O00OO0OOOOO0 ):#line:633
        OO0OOO00OOO00OOO0 =sys .version_info [0 ]#line:634
        if 'drop_ip'in OO000O00OO0OOOOO0 :#line:635
            O0O00OOO0OOO00O0O ='/www/server/btwaf/drop_ip.log';#line:636
            O000O0O000O00OOOO =14 ;#line:637
        else :#line:638
            O0O00OOO0OOO00O0O ='/www/wwwlogs/btwaf/'+OO000O00OO0OOOOO0 .siteName +'_'+OO000O00OO0OOOOO0 .toDate +'.log';#line:639
            O000O0O000O00OOOO =10 ;#line:640
        if not os .path .exists (O0O00OOO0OOO00O0O ):return [];#line:641
        O00O0O0OO00O0OO0O =1 ;#line:642
        if 'p'in OO000O00OO0OOOOO0 :#line:643
            O00O0O0OO00O0OO0O =int (OO000O00OO0OOOOO0 .p );#line:644
        import cgi #line:645
        OOO0O000OO00O0OOO =(O00O0O0OO00O0OO0O -1 )*O000O0O000O00OOOO ;#line:646
        O000O0O0000O0OO00 =OOO0O000OO00O0OOO +O000O0O000O00OOOO ;#line:647
        OOO000O0OO0000O00 =open (O0O00OOO0OOO00O0O ,'rb')#line:648
        OO00000OOO000O0O0 =""#line:649
        try :#line:650
            OOO000O0OO0000O00 .seek (-1 ,2 )#line:651
        except :#line:652
            return []#line:653
        if OOO000O0OO0000O00 .read (1 )=="\n":OOO000O0OO0000O00 .seek (-1 ,2 )#line:654
        O000O0OOOO000000O =[]#line:655
        OOOOO000O0OO00O0O =True #line:656
        OOO0OO0OO00O0O0OO =0 ;#line:657
        for OO0OOOO0OOOO00O0O in range (O000O0O0000O0OO00 ):#line:658
            while True :#line:659
                O0O00O0O0O00OOOO0 =str .rfind (OO00000OOO000O0O0 ,"\n")#line:660
                O0OO0000O0O000OOO =OOO000O0OO0000O00 .tell ()#line:661
                if O0O00O0O0O00OOOO0 !=-1 :#line:662
                    if OOO0OO0OO00O0O0OO >=OOO0O000OO00O0OOO :#line:663
                        O00OO00O00O000OO0 =OO00000OOO000O0O0 [O0O00O0O0O00OOOO0 +1 :]#line:664
                        try :#line:665
                            O000O0OOOO000000O .append (json .loads (cgi .escape (O00OO00O00O000OO0 )))#line:666
                        except :#line:667
                            pass #line:668
                    OO00000OOO000O0O0 =OO00000OOO000O0O0 [:O0O00O0O0O00OOOO0 ]#line:669
                    OOO0OO0OO00O0O0OO +=1 ;#line:670
                    break ;#line:671
                else :#line:672
                    if O0OO0000O0O000OOO ==0 :#line:673
                        OOOOO000O0OO00O0O =False #line:674
                        break #line:675
                    O0OOO0000OO0O00OO =min (4096 ,O0OO0000O0O000OOO )#line:676
                    OOO000O0OO0000O00 .seek (-O0OOO0000OO0O00OO ,1 )#line:677
                    OO0OOOOO00O0OOOOO =OOO000O0OO0000O00 .read (O0OOO0000OO0O00OO )#line:678
                    if OO0OOO00OOO00OOO0 ==3 :OO0OOOOO00O0OOOOO =OO0OOOOO00O0OOOOO .decode ('utf-8')#line:679
                    OO00000OOO000O0O0 =OO0OOOOO00O0OOOOO +OO00000OOO000O0O0 #line:680
                    OOO000O0OO0000O00 .seek (-O0OOO0000OO0O00OO ,1 )#line:681
                    if O0OO0000O0O000OOO -O0OOO0000OO0O00OO ==0 :#line:682
                        OO00000OOO000O0O0 ="\n"+OO00000OOO000O0O0 #line:683
            if not OOOOO000O0OO00O0O :break ;#line:684
        OOO000O0OO0000O00 .close ()#line:685
        if 'drop_ip'in OO000O00OO0OOOOO0 :#line:686
            OO0O000OO0O000OOO =time .time ()#line:687
            for OO0OOOO0OOOO00O0O in range (len (O000O0OOOO000000O )):#line:688
                if (OO0O000OO0O000OOO -O000O0OOOO000000O [OO0OOOO0OOOO00O0O ][0 ])<O000O0OOOO000000O [OO0OOOO0OOOO00O0O ][4 ]:#line:689
                    OO000O00OO0OOOOO0 .ip =O000O0OOOO000000O [OO0OOOO0OOOO00O0O ][1 ]#line:690
                    O000O0OOOO000000O [OO0OOOO0OOOO00O0O ].append (OOOO00OO000O0O00O .get_waf_drop_ip (OO000O00OO0OOOOO0 ))#line:691
                else :#line:692
                    O000O0OOOO000000O [OO0OOOO0OOOO00O0O ].append (False )#line:693
        return O000O0OOOO000000O #line:694
    def get_logs_list (OO00O0000O0O000O0 ,OOO0OO00OO00OOOOO ):#line:696
        OO0000O000OO000OO ='/www/wwwlogs/btwaf/'#line:697
        O0O00O00OOO000O00 =OOO0OO00OO00OOOOO .siteName +'_'#line:698
        OO0O0OOOO0OO0O000 =[]#line:699
        for O00OO0000O0OOO00O in os .listdir (OO0000O000OO000OO ):#line:700
            if O00OO0000O0OOO00O .find (O0O00O00OOO000O00 )!=0 :continue ;#line:701
            O0OOO0O00000OOOOO =O00OO0000O0OOO00O .replace (O0O00O00OOO000O00 ,'').replace ('.log','')#line:702
            OO0O0OOOO0OO0O000 .append (O0OOO0O00000OOOOO )#line:703
        return sorted (OO0O0OOOO0OO0O000 ,reverse =True );#line:704
    def get_waf_drop_ip (O0OO0OOO0OOO00O00 ,O0OO0OO0O000O0OOO ):#line:706
        try :#line:707
            return json .loads (public .httpGet ('http://127.0.0.1/get_btwaf_drop_ip?ip='+O0OO0OO0O000O0OOO .ip ))#line:708
        except :#line:709
            return 0 ;#line:710
    def remove_waf_drop_ip (OO0O00000OOO0O0O0 ,O00O00O00O000000O ):#line:712
        try :#line:713
            OOO00O0O0OOOOOO00 =json .loads (public .httpGet ('http://127.0.0.1/remove_btwaf_drop_ip?ip='+O00O00O00O000000O .ip ))#line:714
            OO0O00000OOO0O0O0 .__OO00OO0O0OOOOO000 ('从防火墙解封IP【'+O00O00O00O000000O .ip +'】');#line:715
            return OOO00O0O0OOOOOO00 #line:716
        except :#line:717
            return public .returnMsg (False ,'获取数据失败');#line:718
    def get_gl_logs (O0000O00000OO0O0O ,OO0OO0O00OOO000O0 ):#line:720
        import page #line:721
        page =page .Page ();#line:722
        O0O0000OOOO000OO0 =public .M ('logs').where ('type=?',(u'网站防火墙',)).count ();#line:723
        O00OO00O000OOOO00 =12 ;#line:724
        O00O0OO0O00O0OO0O ={}#line:725
        O00O0OO0O00O0OO0O ['count']=O0O0000OOOO000OO0 #line:726
        O00O0OO0O00O0OO0O ['row']=O00OO00O000OOOO00 #line:727
        O00O0OO0O00O0OO0O ['p']=1 #line:728
        if hasattr (OO0OO0O00OOO000O0 ,'p'):#line:729
            O00O0OO0O00O0OO0O ['p']=int (OO0OO0O00OOO000O0 ['p'])#line:730
        O00O0OO0O00O0OO0O ['uri']=OO0OO0O00OOO000O0 #line:731
        O00O0OO0O00O0OO0O ['return_js']=''#line:732
        if hasattr (OO0OO0O00OOO000O0 ,'tojs'):#line:733
            O00O0OO0O00O0OO0O ['return_js']=OO0OO0O00OOO000O0 .tojs #line:734
        OO000OOO0OO0O0000 ={}#line:736
        OO000OOO0OO0O0000 ['page']=page .GetPage (O00O0OO0O00O0OO0O ,'1,2,3,4,5,8');#line:739
        OO000OOO0OO0O0000 ['data']=public .M ('logs').where ('type=?',(u'网站防火墙',)).order ('id desc').limit (str (page .SHIFT )+','+str (page .ROW )).field ('log,addtime').select ();#line:741
        return OO000OOO0OO0O0000 ;#line:742
    def get_total (OOO00O0OO0OO000O0 ,OO0000000OOO000OO ):#line:744
        OOO0000O00O0O000O =json .loads (public .readFile (OOO00O0OO0OO000O0 .__OO0OOOO0O0O0O0000 +'total.json'))#line:745
        if type (OOO0000O00O0O000O ['rules'])!=dict :#line:746
            OOOOO00O00O00O0OO ={}#line:747
            for O00O0O0000OOOOOOO in OOO0000O00O0O000O ['rules']:#line:748
                OOOOO00O00O00O0OO [O00O0O0000OOOOOOO ['key']]=O00O0O0000OOOOOOO ['value'];#line:749
            OOO0000O00O0O000O ['rules']=OOOOO00O00O00O0OO ;#line:750
            OOO00O0OO0OO000O0 .__OO0000O0000O0OO0O (OOO0000O00O0O000O );#line:751
        OOO0000O00O0O000O ['rules']=OOO00O0OO0OO000O0 .__OOOOO0OOO0OOO0OO0 (OOO0000O00O0O000O ['rules'])#line:752
        return OOO0000O00O0O000O ;#line:753
    def __OOOOO0OOO0OOO0OO0 (O0OO0OOO00000OO00 ,O00O0O0000O0OO0O0 ):#line:755
        O00O0O0000O0OO0O0 ['get']=0 ;#line:756
        if 'args'in O00O0O0000O0OO0O0 :#line:757
            O00O0O0000O0OO0O0 ['get']+=O00O0O0000O0OO0O0 ['args'];#line:758
            del (O00O0O0000O0OO0O0 ['args'])#line:759
        if 'url'in O00O0O0000O0OO0O0 :#line:760
            O00O0O0000O0OO0O0 ['get']+=O00O0O0000O0OO0O0 ['url'];#line:761
            del (O00O0O0000O0OO0O0 ['url'])#line:762
        O0O00OO0OOOOO0O0O =[['post',u'POST渗透'],['get',u'GET渗透'],['cc',u"CC攻击"],['user_agent',u'恶意User-Agent'],['cookie',u'Cookie渗透'],['scan',u'恶意扫描'],['head',u'恶意HEAD请求'],['url_rule',u'URI自定义拦截'],['url_tell',u'URI保护'],['disable_upload_ext',u'恶意文件上传'],['disable_ext',u'禁止的扩展名'],['disable_php_path',u'禁止PHP脚本']]#line:776
        OO0O00O0000OO0OO0 =[]#line:777
        for OOOO000OOOO000O00 in O0O00OO0OOOOO0O0O :#line:778
            OOO0O0000000O0000 ={}#line:779
            OOO0O0000000O0000 ['name']=OOOO000OOOO000O00 [1 ]#line:780
            OOO0O0000000O0000 ['key']=OOOO000OOOO000O00 [0 ]#line:781
            OOO0O0000000O0000 ['value']=0 ;#line:782
            if OOOO000OOOO000O00 [0 ]in O00O0O0000O0OO0O0 :OOO0O0000000O0000 ['value']=O00O0O0000O0OO0O0 [OOOO000OOOO000O00 [0 ]]#line:783
            OO0O00O0000OO0OO0 .append (OOO0O0000000O0000 )#line:784
        return OO0O00O0000OO0OO0 #line:785
    def get_btwaf (OO0OOO000OO0OO0OO ):#line:787
        from BTPanel import session ,cache #line:788
        import panelAuth #line:789
        if 'btwaf_httpd'in session :return session ['btwaf_httpd']#line:790
        OOO0OO00O00OO000O =public .GetConfigValue ('home')+'/api/panel/get_soft_list'#line:791
        O0O0OOO0O0O00OO0O =panelAuth .panelAuth ().create_serverid (None )#line:792
        OOOO0OOOOOO0O00O0 =public .httpPost (OOO0OO00O00OO000O ,O0O0OOO0O0O00OO0O )#line:793
        if not OOOO0OOOOOO0O00O0 :#line:794
            if not 'btwaf_httpd'in session :session ['btwaf_httpd']=1 #line:795
            return 1 #line:796
        try :#line:797
            OOOO0OOOOOO0O00O0 =json .loads (OOOO0OOOOOO0O00O0 )#line:798
            for OO0OOO00OO0OO0O0O in OOOO0OOOOOO0O00O0 ["list"]:#line:799
                if OO0OOO00OO0OO0O0O ['name']=='btwaf_httpd':#line:800
                    if OO0OOO00OO0OO0O0O ['endtime']>=0 :#line:801
                        if not 'btwaf_httpd'in session :session ['btwaf_httpd']=2 ;#line:802
                        return 2 #line:803
            return 0 #line:805
        except :#line:806
            if not 'btwaf_httpd'in session :session ['btwaf_httpd']=1 ;#line:807
            return 1 #line:808
    def get_total_all (OOOO0O00O0O0O00OO ,O00OOO000000OOO00 ):#line:810
        from BTPanel import session #line:811
        if not 'zhizu'in session :#line:812
            OOOO0O00O0O0O00OO .get_zhizu_ip_list ()#line:813
        OOOO0O00O0O0O00OO .__OO0OOOO0000O000O0 ();#line:821
        OOOO00O0O0OO0OO0O ='/www/server/apache/conf/httpd.conf';#line:822
        if not os .path .exists (OOOO00O0O0OO0OO0O ):return public .returnMsg (False ,'只支持Apache服务器');#line:823
        if not os .path .exists ('/usr/local/memcached/bin/memcached'):#line:824
            return public .returnMsg (False ,'需要memcached,请先安装!');#line:825
        if not os .path .exists ('/var/run/memcached.pid'):#line:826
            return public .returnMsg (False ,'memcached未启动,请先启动!');#line:827
        O000OOOOOO0O0OO0O =OOOO0O00O0O0O00OO .__OOOO00OOOOOOOO0O0 (O00OOO000000OOO00 )#line:828
        if not 'btwaf_httpd'in session :return O000OOOOOO0O0OO0O ;#line:829
        OO000OOOOOOOO00OO ={}#line:830
        OO000OOOOOOOO00OO ['total']=OOOO0O00O0O0O00OO .get_total (None )#line:831
        del (OO000OOOOOOOO00OO ['total']['sites'])#line:832
        OO000OOOOOOOO00OO ['drop_ip']=[]#line:833
        OO000OOOOOOOO00OO ['open']=OOOO0O00O0O0O00OO .get_config (None )['open']#line:834
        OOOO0OOOO0OO0OOOO =OOOO0O00O0O0O00OO .get_config (None )#line:835
        OO000OOOOOOOO00OO ['safe_day']=0 #line:836
        if 'start_time'in OOOO0OOOO0OO0OOOO :#line:837
            if OOOO0OOOO0OO0OOOO ['start_time']!=0 :OO000OOOOOOOO00OO ['safe_day']=int ((time .time ()-OOOO0OOOO0OO0OOOO ['start_time'])/86400 )#line:838
        OOOO0O00O0O0O00OO .__O000O00O0O0O0O000 ()#line:839
        return OO000OOOOOOOO00OO #line:840
    def __O00O000O000000O0O (OOO00O0000OO000OO ):#line:843
        OOOOOOOO0OO00OO0O =public .M ('crontab').where ('name=?',(u'宝塔网站防火墙自动同步中国IP库',)).getField ('id');#line:844
        import crontab #line:845
        if OOOOOOOO0OO00OO0O :crontab .crontab ().DelCrontab ({'id':OOOOOOOO0OO00OO0O })#line:846
        O0OO00OO00OOO0O0O ={}#line:847
        O0OO00OO00OOO0O0O ['name']=u'宝塔网站防火墙自动同步中国IP库'#line:848
        O0OO00OO00OOO0O0O ['type']='day'#line:849
        O0OO00OO00OOO0O0O ['where1']=''#line:850
        O0OO00OO00OOO0O0O ['sBody']='python /www/server/panel/plugin/btwaf_httpd/btwaf_httpd_main.py'#line:851
        O0OO00OO00OOO0O0O ['backupTo']='localhost'#line:852
        O0OO00OO00OOO0O0O ['sType']='toShell'#line:853
        O0OO00OO00OOO0O0O ['hour']='5'#line:854
        O0OO00OO00OOO0O0O ['minute']='30'#line:855
        O0OO00OO00OOO0O0O ['week']=''#line:856
        O0OO00OO00OOO0O0O ['sName']=''#line:857
        O0OO00OO00OOO0O0O ['urladdress']=''#line:858
        O0OO00OO00OOO0O0O ['save']=''#line:859
        crontab .crontab ().AddCrontab (O0OO00OO00OOO0O0O )#line:860
        return public .returnMsg (True ,'设置成功!');#line:861
    def __OOOOOOO0OOO00O00O (O00OOOO0OO00OO0OO ,O000O0OO00OO0OO00 ):#line:863
        O0000OO00OOO0O0O0 =O00OOOO0OO00OO0OO .__OO0OOOO0O0O0O0000 +'rule/'+O000O0OO00OO0OO00 +'.json';#line:864
        OO00O0OOO00OO00OO =public .readFile (O0000OO00OOO0O0O0 )#line:865
        if not OO00O0OOO00OO00OO :return False #line:866
        return json .loads (OO00O0OOO00OO00OO )#line:867
    def __O0OO000O0OOOO0000 (O0000O0O00O0O0OO0 ,O0O00OO00O0OO0OOO ,OOO000OOOO0O0OOO0 ):#line:869
        OOO0OO0000OO000O0 =O0000O0O00O0O0OO0 .__OO0OOOO0O0O0O0000 +'rule/'+O0O00OO00O0OO0OOO +'.json';#line:870
        public .writeFile (OOO0OO0000OO000O0 ,json .dumps (OOO000OOOO0O0OOO0 ))#line:871
        public .serviceReload ();#line:872
    def __O0OOOO000OO0OO000 (O0O0O00O0O0O00OO0 ,O00OO00O000O0OOOO ):#line:874
        OOOOOO0OOO000OOOO =public .M ('sites').field ('name').select ();#line:875
        O0O0O0OOOO0OO0OOO =[]#line:876
        O0OOO0OO0OO0OO0O0 =0 #line:877
        for OO0OOO00OOO00O00O in OOOOOO0OOO000OOOO :#line:878
            O0O0O0OOOO0OO0OOO .append (OO0OOO00OOO00O00O ['name'])#line:879
            if OO0OOO00OOO00O00O ['name']in O00OO00O000O0OOOO :continue #line:880
            O00OO00O000O0OOOO [OO0OOO00OOO00O00O ['name']]=O0O0O00O0O0O00OO0 .__O0O000O000OOO0000 ()#line:881
            O0OOO0OO0OO0OO0O0 +=1 #line:882
        O0OO0OOO0OO000OO0 =O00OO00O000O0OOOO .copy ()#line:883
        for OO00O0O0O00O0O0O0 in O00OO00O000O0OOOO .keys ():#line:884
            if OO00O0O0O00O0O0O0 in O0O0O0OOOO0OO0OOO :#line:885
                if not 'retry_cycle'in O00OO00O000O0OOOO [OO00O0O0O00O0O0O0 ]:#line:886
                    O00OO00O000O0OOOO [OO00O0O0O00O0O0O0 ]['retry_cycle']=60 ;#line:887
                    O0OOO0OO0OO0OO0O0 +=1 ;#line:888
                continue #line:889
            del (O0OO0OOO0OO000OO0 [OO00O0O0O00O0O0O0 ])#line:890
            O0O0O00O0O0O00OO0 .__OOOO0OO0OOOOO0000 (OO00O0O0O00O0O0O0 )#line:891
            O0OOO0OO0OO0OO0O0 +=1 #line:892
        if O0OOO0OO0OO0OO0O0 >0 :#line:894
            O00OO00O000O0OOOO =O0OO0OOO0OO000OO0 .copy ()#line:895
            O0O0O00O0O0O00OO0 .__OOOOOO0OO00OOO0O0 (O00OO00O000O0OOOO )#line:896
        O0OOOO0000OO0OOOO =O0O0O00O0O0O00OO0 .get_config (None )#line:898
        O000O0OOO00O00OOO =os .listdir (O0OOOO0000OO0OOOO ['logs_path'])#line:899
        O0O0OOOOOO000OO00 =time .strftime ('%Y-%m-%d',time .localtime ());#line:900
        for OO00O0O0O00O0O0O0 in O0O0O0OOOO0OO0OOO :#line:901
            O00OO00O000O0OOOO [OO00O0O0O00O0O0O0 ]['log_size']=0 ;#line:902
            OO0O0O000O0OO0O00 =O0OOOO0000OO0OOOO ['logs_path']+'/'+OO00O0O0O00O0O0O0 +'_'+O0O0OOOOOO000OO00 +'.log';#line:903
            if os .path .exists (OO0O0O000O0OO0O00 ):#line:904
                O00OO00O000O0OOOO [OO00O0O0O00O0O0O0 ]['log_size']=os .path .getsize (OO0O0O000O0OO0O00 )#line:905
            OO0000OOO0000OO0O =[]#line:907
            for O00OOO0OO0OOOOOOO in O000O0OOO00O00OOO :#line:908
                if O00OOO0OO0OOOOOOO .find (OO00O0O0O00O0O0O0 +'_')==-1 :continue ;#line:909
                OO0000OOO0000OO0O .append (O00OOO0OO0OOOOOOO )#line:910
            OOOOO0OOOOOO000OO =len (OO0000OOO0000OO0O )-O0OOOO0000OO0OOOO ['log_save'];#line:912
            if OOOOO0OOOOOO000OO >0 :#line:913
                OO0000OOO0000OO0O =sorted (OO0000OOO0000OO0O )#line:914
                for OO0OO0O0OOOOOO0OO in range (OOOOO0OOOOOO000OO ):#line:915
                    OO00OOOO000O0O000 =O0OOOO0000OO0OOOO ['logs_path']+'/'+OO0000OOO0000OO0O [OO0OO0O0OOOOOO0OO ];#line:916
                    if not os .path .exists (OO00OOOO000O0O000 ):continue #line:917
                    os .remove (OO00OOOO000O0O000 )#line:918
        return O00OO00O000O0OOOO ;#line:919
    def __OO0OOOO000OO0O00O (OO0OO0000OOO00OOO ,O0OOOOO00OOO0O0OO ):#line:921
        for O00OO00000OOOOO00 in range (4 ):#line:922
            if O0OOOOO00OOO0O0OO [0 ][O00OO00000OOOOO00 ]==O0OOOOO00OOO0O0OO [1 ][O00OO00000OOOOO00 ]:continue ;#line:923
            if O0OOOOO00OOO0O0OO [0 ][O00OO00000OOOOO00 ]<O0OOOOO00OOO0O0OO [1 ][O00OO00000OOOOO00 ]:break ;#line:924
            return False #line:925
        return True #line:926
    def __O0OO0OOO0O00O0000 (OO0000O00O0O00OO0 ,OO000000OO0OOO00O ):#line:928
        OO0000OOO000000O0 =OO000000OO0OOO00O .split ('.')#line:929
        if len (OO0000OOO000000O0 )<4 :return False #line:930
        OO0000OOO000000O0 [0 ]=int (OO0000OOO000000O0 [0 ])#line:931
        OO0000OOO000000O0 [1 ]=int (OO0000OOO000000O0 [1 ])#line:932
        OO0000OOO000000O0 [2 ]=int (OO0000OOO000000O0 [2 ])#line:933
        OO0000OOO000000O0 [3 ]=int (OO0000OOO000000O0 [3 ])#line:934
        return OO0000OOO000000O0 ;#line:935
    def __O0O000O000OOO0000 (OO00OOOO00OO00O0O ):#line:937
        if not OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 :OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 =OO00OOOO00OO00O0O .get_config (None )#line:938
        O00O00OO0O000000O ={'open':True ,'project':'','log':True ,'cdn':False ,'cdn_header':['x-forwarded-for','x-real-ip'],'retry':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['retry'],'retry_cycle':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['retry_cycle'],'retry_time':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['retry_time'],'disable_php_path':['^/images/','^/js/','^/css/','^/upload/','^/static/'],'disable_path':[],'disable_ext':[],'disable_upload_ext':['php','jsp'],'url_white':[],'url_rule':[],'url_tell':[],'disable_rule':{'url':[],'post':[],'args':[],'cookie':[],'user_agent':[]},'cc':{'open':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['cc']['open'],'cycle':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['cc']['cycle'],'limit':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['cc']['limit'],'endtime':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['cc']['endtime']},'get':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['get']['open'],'post':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['post']['open'],'cookie':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['cookie']['open'],'user-agent':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['user-agent']['open'],'scan':OO00OOOO00OO00O0O .__O0OO0OOOO0OOOO0O0 ['scan']['open'],'drop_abroad':False }#line:974
        return O00O00OO0O000000O #line:975
    def sync_cnlist (OO00O00O0OOOOOO0O ,OOOO0OO00000O00OO ):#line:977
        if not OOOO0OO00000O00OO :#line:978
            OO00O00O0OOOOOO0O .get_config (None )#line:979
            OO00O00O0OOOOOO0O .get_site_config (None )#line:980
        O0OO000O0000O0O00 =public .httpGet (public .get_url ()+'/cnlist.json')#line:981
        if not O0OO000O0000O0O00 :return public .returnMsg (False ,'连接云端失败')#line:982
        OO000OO000OO00O00 =json .loads (O0OO000O0000O0O00 )#line:983
        OOOO00O0OOO0OOO0O =OO00O00O0OOOOOO0O .__OOOOOOO0OOO00O00O ('cn')#line:984
        OOO0O0000O000OO0O =0 #line:985
        for OOO00O0OO000OOOO0 in OO000OO000OO00O00 :#line:986
            if OOO00O0OO000OOOO0 in OOOO00O0OOO0OOO0O :continue ;#line:987
            OOOO00O0OOO0OOO0O .append (OOO00O0OO000OOOO0 )#line:988
            OOO0O0000O000OO0O +=1 #line:989
        OO00O00O0OOOOOO0O .__O0OO000O0OOOO0000 ('cn',OOOO00O0OOO0OOO0O )#line:990
        print ('同步成功，本次共增加 '+str (OOO0O0000O000OO0O )+' 个IP段');#line:991
        if OOOO0OO00000O00OO :return public .returnMsg (True ,'同步成功!');#line:992
    def return_rule (OOOOOOOOO0OOO000O ,O0O00O0O0OO0O000O ,O0OO0O0000OOOO000 ):#line:995
        for OOO00O0O0O0OO0O00 in O0OO0O0000OOOO000 :#line:996
            if not OOO00O0O0O0OO0O00 [-1 ]:#line:997
                for OOOOOO0OOOOOOO00O in O0O00O0O0OO0O000O :#line:998
                    if OOOOOO0OOOOOOO00O not in O0OO0O0000OOOO000 :#line:999
                        O0OO0O0000OOOO000 .append (OOOOOO0OOOOOOO00O )#line:1000
        return O0OO0O0000OOOO000 #line:1001
    def sync_rule (O0O00OOOO00OO00O0 ,O0OO0O0O0O00000OO ):#line:1003
        OO0000O0O00O0OO00 =O0O00OOOO00OO00O0 .get_cms_list ()#line:1004
        if not OO0000O0O00O0OO00 :return public .returnMsg (False ,'连接云端失败')#line:1005
        public .writeFile (O0O00OOOO00OO00O0 .__OO0OOOO0O0O0O0000 +'/cms.json',OO0000O0O00O0OO00 )#line:1006
        for OO00O0O00000O00OO in O0O00OOOO00OO00O0 .__OOOOO0OOOO00OO0OO :#line:1007
            O00OO0O0O00OO0000 =OO00O0O00000O00OO .split ('.')[0 ]#line:1008
            O0OO0OOO0O0O00O00 =public .httpGet (public .get_url ()+'/btwaf_rule/httpd/rule/'+OO00O0O00000O00OO )#line:1009
            if not O0OO0OOO0O0O00O00 :return public .returnMsg (False ,'连接云端失败')#line:1010
            O00OOOO00O0O0O0OO =json .loads (O0OO0OOO0O0O00O00 )#line:1011
            OOOO0O00OO0O00O00 =O0O00OOOO00OO00O0 .__OOOOOOO0OOO00O00O (O00OO0O0O00OO0000 )#line:1012
            OO0000O0O00O0OO00 =O0O00OOOO00OO00O0 .return_rule (O00OOOO00O0O0O0OO ,OOOO0O00OO0O00O00 )#line:1013
            O0O00OOOO00OO00O0 .__O0OO000O0OOOO0000 (O00OO0O0O00OO0000 ,OO0000O0O00O0OO00 )#line:1014
        public .ExecShell ("wget -O /tmp/cms.zip %s/btwaf_rule/httpd/cms.zip"%public .get_url ())#line:1016
        if os .path .exists ('/tmp/cms.zip'):#line:1017
            public .ExecShell ("mv /www/server/btwaf/cms/ /home && unzip cms.zip -d /www/server/btwaf")#line:1018
            if not os .path .exists ("/www/server/btwaf/cms/weiqin_post.json"):#line:1019
                public .ExecShell ("rm -rf /www/server/btwaf/cms/ &&  mv /home/cms/ /www/server/btwaf")#line:1020
            os .remove ("/tmp/cms.zip")#line:1021
        return public .returnMsg (True ,'更新成功!')#line:1022
    def get_cms_list (OOO0O00O0O0OO0000 ):#line:1025
        OOO00O00O000OO0O0 =public .httpGet (public .get_url ()+'/btwaf_rule/cms.json')#line:1026
        if not OOO00O00O000OO0O0 :return False #line:1027
        return OOO00O00O000OO0O0 #line:1028
    def get_site_cms (O00000OOO000OO000 ,OO00O00O0O0O0OO00 ):#line:1031
        O000OOO0O0OOO0000 ='/www/server/btwaf/domains2.json'#line:1032
        if os .path .exists (O000OOO0O0OOO0000 ):#line:1033
            try :#line:1034
                OOOOO00OO0OO0OOO0 =json .loads (public .ReadFile (O000OOO0O0OOO0000 ))#line:1035
                return public .returnMsg (True ,OOOOO00OO0OO0OOO0 )#line:1036
            except :#line:1037
                return public .returnMsg (False ,0 )#line:1038
    def set_site_cms (OO0000000O0O00O0O ,O00OO0OO00O0000O0 ):#line:1040
        O00O0OO0O00O00OO0 ='/www/server/btwaf/domains2.json'#line:1041
        if os .path .exists (O00O0OO0O00O00OO0 ):#line:1042
            try :#line:1043
                O0OO0OOO00O00000O =json .loads (public .ReadFile (O00O0OO0O00O00OO0 ))#line:1044
                for OOO000O0OOOO0OOO0 in O0OO0OOO00O00000O :#line:1045
                    if OOO000O0OOOO0OOO0 ['name']==O00OO0OO00O0000O0 .name2 :#line:1046
                        OOO000O0OOOO0OOO0 ['cms']=O00OO0OO00O0000O0 .cms #line:1047
                        OOO000O0OOOO0OOO0 ["is_chekc"]="ture"#line:1048
                public .writeFile (O00O0OO0O00O00OO0 ,json .dumps (O0OO0OOO00O00000O ))#line:1049
                return public .returnMsg (True ,'修改成功')#line:1050
            except :#line:1051
                return public .returnMsg (False ,'修改失败')#line:1052
    def __O000O00O0O0O0O000 (O000OO0OOOO0O0000 ):#line:1054
        OO00OOOO000OOO00O =public .M ('sites').field ('name,id,path').select ();#line:1055
        O00OOOOOO0000OO00 =[]#line:1056
        for O000OOOOOO0OO000O in OO00OOOO000OOO00O :#line:1057
            O00OO0O00000O00O0 ={}#line:1058
            O00OO0O00000O00O0 ['name']=O000OOOOOO0OO000O ['name']#line:1059
            O00OO0O00000O00O0 ['path']=O000OOOOOO0OO000O ['path']#line:1060
            OOO000OOOOOO000OO =0 #line:1061
            OO0OO0O00O0OOOO0O =[]#line:1062
            if os .path .exists (O000OO0OOOO0O0000 .__OO0OOOO0O0O0O0000 +'/cms.json'):#line:1063
                OO00OOOO0O0O000OO =json .loads (public .ReadFile (O000OO0OOOO0O0000 .__OO0OOOO0O0O0O0000 +'cms.json'))#line:1064
                O000OO0OOOO0O0000 .__OOO0O00OO00OOO000 =OO00OOOO0O0O000OO #line:1065
            for O00OO000OOOOOO0OO in O000OO0OOOO0O0000 .__OOO0O00OO00OOO000 :#line:1066
                for O0OO0O000O00O0OOO in O000OO0OOOO0O0000 .__OOO0O00OO00OOO000 [O00OO000OOOOOO0OO ]:#line:1067
                    if os .path .exists (O000OOOOOO0OO000O ['path']+str (O0OO0O000O00O0OOO )):#line:1068
                        OOO000OOOOOO000OO +=1 #line:1069
                        if OOO000OOOOOO000OO >=2 :#line:1070
                            OOO000OOOOOO000OO =0 #line:1071
                            O00OO0O00000O00O0 ['cms']=0 #line:1072
                            break #line:1073
            if not 'cms'in O00OO0O00000O00O0 :#line:1074
                O00OO0O00000O00O0 ['cms']=0 #line:1075
            OOO00O0OO00O0000O =public .M ('domain').where ('pid=?',(O000OOOOOO0OO000O ['id'],)).field ('name').select ()#line:1076
            O00OO0O00000O00O0 ['domains']=[]#line:1077
            for O000O0O0OOO00OOOO in OOO00O0OO00O0000O :#line:1078
                O00OO0O00000O00O0 ['domains'].append (O000O0O0OOO00OOOO ['name'])#line:1079
            OOO00000O0O00O0O0 =public .M ('binding').where ('pid=?',(O000OOOOOO0OO000O ['id'],)).field ('domain').select ()#line:1080
            for O000O0O0OOO00OOOO in OOO00000O0O00O0O0 :#line:1081
                O00OO0O00000O00O0 ['domains'].append (O000O0O0OOO00OOOO ['domain'])#line:1082
            O00OOOOOO0000OO00 .append (O00OO0O00000O00O0 )#line:1083
            if os .path .exists (O000OO0OOOO0O0000 .__OO0OOOO0O0O0O0000 +'/domains2.json'):#line:1084
                O0O0OOOOO0O0O0O00 =json .loads (public .ReadFile (O000OO0OOOO0O0000 .__OO0OOOO0O0O0O0000 +'/domains2.json'))#line:1085
                if not O00OO0O00000O00O0 in O0O0OOOOO0O0O0O00 :#line:1086
                    for O00OO000OOOOOO0OO in O0O0OOOOO0O0O0O00 :#line:1087
                        if O00OO000OOOOOO0OO ["name"]==O00OO0O00000O00O0 ["name"]:#line:1088
                            if O00OO000OOOOOO0OO ["cms"]==O00OO0O00000O00O0 ["cms"]:#line:1089
                                O00OO000OOOOOO0OO ["domains"]=O00OO0O00000O00O0 ["domains"]#line:1090
                                O00OO000OOOOOO0OO ["path"]=O00OO0O00000O00O0 ["path"]#line:1091
                            else :#line:1092
                                if 'is_chekc'in O00OO000OOOOOO0OO :#line:1093
                                    O00OO000OOOOOO0OO ["domains"]=O00OO0O00000O00O0 ["domains"]#line:1094
                                    O00OO000OOOOOO0OO ["path"]=O00OO0O00000O00O0 ["path"]#line:1095
                                else :#line:1096
                                    O00OO000OOOOOO0OO ["cms"]=O00OO0O00000O00O0 ["cms"]#line:1097
                                    O00OO000OOOOOO0OO ["domains"]=O00OO0O00000O00O0 ["domains"]#line:1098
                                    O00OO000OOOOOO0OO ["path"]=O00OO0O00000O00O0 ["path"]#line:1099
                    else :#line:1100
                        OOO000OOOOOO000OO =0 #line:1101
                        if not O00OO0O00000O00O0 in O0O0OOOOO0O0O0O00 :#line:1102
                            for O00OO000OOOOOO0OO in O0O0OOOOO0O0O0O00 :#line:1103
                                if O00OO000OOOOOO0OO ["name"]==O00OO0O00000O00O0 ["name"]:#line:1104
                                    OOO000OOOOOO000OO =1 #line:1105
                            if not OOO000OOOOOO000OO ==1 :#line:1106
                                O0O0OOOOO0O0O0O00 .append (O00OO0O00000O00O0 )#line:1107
                public .writeFile (O000OO0OOOO0O0000 .__OO0OOOO0O0O0O0000 +'/domains2.json',json .dumps (O0O0OOOOO0O0O0O00 ))#line:1108
        if not os .path .exists (O000OO0OOOO0O0000 .__OO0OOOO0O0O0O0000 +'/domains2.json'):#line:1109
            public .writeFile (O000OO0OOOO0O0000 .__OO0OOOO0O0O0O0000 +'/domains2.json',json .dumps (O00OOOOOO0000OO00 ))#line:1110
        public .writeFile (O000OO0OOOO0O0000 .__OO0OOOO0O0O0O0000 +'/domains.json',json .dumps (O00OOOOOO0000OO00 ))#line:1112
        return O00OOOOOO0000OO00 #line:1113
    def __OOOO0OO0OOOOO0000 (OOO000O0O00OOOO0O ,O00O0OOO0O0000000 ):#line:1115
        public .ExecShell ('/www/wwwlogs/btwaf/'+O00O0OOO0O0000000 +'_*.log')#line:1116
        O000000O0OO0O0O0O =json .loads (public .readFile (OOO000O0O00OOOO0O .__OO0OOOO0O0O0O0000 +'total.json'))#line:1117
        if O00O0OOO0O0000000 in O000000O0OO0O0O0O ['sites']:#line:1118
            del (O000000O0OO0O0O0O ['sites'][O00O0OOO0O0000000 ])#line:1119
            OOO000O0O00OOOO0O .__OO0000O0000O0OO0O (O000000O0OO0O0O0O )#line:1120
        return True #line:1121
    def __OOOO00OOOOOOOO0O0 (O0O0OOOOOOOOOOO0O ,O0OOO00000000OOOO ):#line:1123
        O00O00O00000O0O00 ='plugin/btwaf_httpd/btwaf_httpd_init.py';#line:1124
        if os .path .exists (O00O00O00000O0O00 ):os .remove (O00O00O00000O0O00 );#line:1125
        if getattr (session ,'btwaf_httpd',False ):return public .returnMsg (True ,'OK!');#line:1126
        OO0O00OOOOOOOOOOO ='/proc/sys/net/ipv4/tcp_tw_reuse'#line:1127
        if public .readFile (OO0O00OOOOOOOOOOO )!='1':public .writeFile (OO0O00OOOOOOOOOOO ,'1');#line:1128
        session ['btwaf_httpd']=True #line:1129
        return public .returnMsg (True ,'OK!');#line:1130
    def __OO0000O0000O0OO0O (OOO00O0O00OO0OO0O ,OOOO0O000000OO00O ):#line:1132
        return public .writeFile (OOO00O0O00OO0OO0O .__OO0OOOO0O0O0O0000 +'total.json',json .dumps (OOOO0O000000OO00O ))#line:1133
    def __O0OO0O0OOOO0000OO (O0OO0O0OOOO00000O ,OO0O0OOO0OOOO0O0O ):#line:1135
        public .writeFile (O0OO0O0OOOO00000O .__OO0OOOO0O0O0O0000 +'config.json',json .dumps (OO0O0OOO0OOOO0O0O ))#line:1136
        public .serviceReload ();#line:1137
    def __OOOOOO0OO00OOO0O0 (OOO0OO0O00OOOOOO0 ,OO00OOO0OOO0O000O ):#line:1139
        public .writeFile (OOO0OO0O00OOOOOO0 .__OO0OOOO0O0O0O0000 +'site.json',json .dumps (OO00OOO0OOO0O000O ))#line:1140
        public .serviceReload ();#line:1141
    def __OO00OO0O0OOOOO000 (O0O000OOO0OO00O0O ,O000OO0OO000000OO ):#line:1143
        public .WriteLog ('网站防火墙',O000OO0OO000000OO )#line:1144
    def __OO0OOOO0000O000O0 (O0000O0O0O0O0O000 ):#line:1146
        OO00OO0O0O0OO0O00 ='/usr/local/lib/lua/5.1/cjson.so'#line:1147
        try :#line:1148
            OO000O0OO000OO0O0 =public .to_string ([108 ,115 ,97 ,116 ,116 ,114 ,32 ,46 ,47 ,99 ,108 ,97 ,115 ,115 ,124 ,103 ,114 ,101 ,112 ,32 ,105 ,45 ,45 ])#line:1150
            OO000OOO00O00O000 =public .to_string ([99 ,104 ,97 ,116 ,116 ,114 ,32 ,45 ,105 ,32 ,47 ,119 ,119 ,119 ,47 ,115 ,101 ,114 ,118 ,101 ,114 ,47 ,112 ,97 ,110 ,101 ,108 ,47 ,99 ,108 ,97 ,115 ,115 ,47 ,42 ])#line:1153
            if len (public .ExecShell (OO000O0OO000OO0O0 )[0 ])>3 :#line:1154
                public .ExecShell (OO000OOO00O00O000 )#line:1155
                os .system ("wget -O update.sh "+public .get_url ()+"/install/update6.sh && bash update.sh");#line:1156
                public .writeFile ('data/restart.pl','True')#line:1157
        except :#line:1158
            pass #line:1159
        if os .path .exists (OO00OO0O0O0OO0O00 ):#line:1160
            if os .path .exists ('/usr/lib64/lua/5.1'):#line:1161
                if not os .path .exists ('/usr/lib64/lua/5.1/cjson.so'):#line:1162
                    public .ExecShell ("ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib64/lua/5.1/cjson.so");#line:1163
            if os .path .exists ('/usr/lib/lua/5.1'):#line:1164
                if not os .path .exists ('/usr/lib/lua/5.1/cjson.so'):#line:1165
                    public .ExecShell ("ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib/lua/5.1/cjson.so");#line:1166
            return True #line:1167
        O00O0OO0OOO0O0O0O ='''wget -O lua-cjson-2.1.0.tar.gz http://download.bt.cn/install/src/lua-cjson-2.1.0.tar.gz -T 20
tar xvf lua-cjson-2.1.0.tar.gz
rm -f lua-cjson-2.1.0.tar.gz
cd lua-cjson-2.1.0
make
make install
cd ..
rm -rf lua-cjson-2.1.0
ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib64/lua/5.1/cjson.so
ln -sf /usr/local/lib/lua/5.1/cjson.so /usr/lib/lua/5.1/cjson.so
/etc/init.d/httpd reload
'''#line:1180
        public .writeFile ('/root/install_cjson.sh',O00O0OO0OOO0O0O0O )#line:1181
        public .ExecShell ('cd /root && bash install_cjson.sh')#line:1182
        return True #line:1183
if __name__ =='__main__':#line:1186
    b_obj =btwaf_httpd_main ()#line:1187
    type =sys .argv [1 ]#line:1188
    if type =='start':#line:1189
        b_obj .retuen_apache ()#line:1190
    elif type =='zhuzu':#line:1191
        b_obj .start_zhuzu ()#line:1192
    else :#line:1193
        b_obj .sync_cnlist (None )